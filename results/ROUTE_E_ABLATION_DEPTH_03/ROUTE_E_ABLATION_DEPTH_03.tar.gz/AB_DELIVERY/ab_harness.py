"""ROUTE_E_ABLATION_DEPTH_DEV_03 — jusqu'ou le retrait pur descend-il le residu,
et ou casse la survie ? Tir direct sur la porte gelee de Route E (residu <= 0.20)."""
from __future__ import annotations
import csv, json, math, time
from pathlib import Path
import numpy as np
from od_core import *
from od_ops import do_event
from bridge00_harness import law_arms
from morph02_ic import ic_single_disc
CAD=16; T_B=256; T_F=1536; T_E=2048; P=0.35; SIZES=(24,32); SEEDS_PER=9
DOSES=[0.0,0.15,0.30,0.50,0.70,1.00,1.40,2.00]
ARMS=[("SHAM" if d==0 else f"ABLATION_{d:.2f}") for d in DOSES]
AXORD=("+x","-x","+y","-y"); SMOOTH=[272+16*(e-1) for e in range(1,81)]
def prephase(law,m,L):
    eng=LatticeBondEngine(law); st=LatticeBondState(m.copy(),np.full((L,L),0.8),np.zeros((2,L,L)),0)
    while int(st.step)<T_B: st=eng.step(st).state
    return st
def branch(law,st0,masks,arm,d,L,M256,cs256):
    eng=LatticeBondEngine(law); st=st0.copy()
    init=np.zeros_like(st.m); fi=init.reshape(-1); fm=st.m.reshape(-1)
    for i in cs256: fi[i]=fm[i]
    fresh=np.zeros_like(st.m); S=set(SMOOTH); Q=d*M256; qe=Q/80 if d>0 else 0.0
    res={"sink":0.0,"source":0.0}; tot0=float(st.m.sum())
    egress=0.0; rem=0.0; defi=0.0; first=None; ftype="NONE"; prev=None; snap={}
    t=int(st.step)
    while t<T_E:
        if t in S and d>0:
            pt=per_track(st,init,fresh,M256)
            r=do_event(st,init,fresh,pt["cells"],masks,"SINK_ONLY_DISTRIBUTED",qe,L,res)
            rem+=r["removed"]; egress+=r["init_egress"]; defi+=r["deficit"]
        pre=st; out=eng.step(pre)
        init=advect(init,pre.m,out.ledger,out.state.m,law.dt)
        st=out.state; t=int(st.step)
        if t%CAD==0:
            pt=per_track(st,init,fresh,M256)
            bad=None
            if not pt["track"]: bad="TRACK_LOST_OR_DISSOLVED"
            elif pt["wrap"]: bad="WRAPPING"
            elif prev is not None:
                dd=math.hypot(pt["cy"]-prev["cy"],pt["cx"]-prev["cx"]); ar=pt["area"]/max(1,prev["area"])
                if dd>3.0 or not (1/3.0<=ar<=3.0): bad="TRACK_LOSS"
            if bad and first is None: first=t; ftype=bad
            if pt["track"]: prev=pt
            if t in (1536,2048): snap[t]=pt
    sys_err=abs(float(st.m.sum())+res["sink"]+res["source"]-tot0)
    def alive(H): return first is None or first>H
    def v(H,k):
        s=snap.get(H); return s[k] if (s and s["endpoint_defined"] and alive(H)) else None
    r15=v(1536,"initial_residual"); r20=v(2048,"initial_residual")
    # PORTE ROUTE E GELEE: composant borne non enroule, suivi en continu, residu <= 0.20
    route_e = bool(alive(2048) and r15 is not None and r20 is not None and r15<=0.20 and r20<=0.20)
    return {"arm":arm,"dose":d,"M256":M256,"Q":Q,"realized_removal":rem,"unique_initial_egress":egress,
            "flux_deficit":defi,"total_system_balance_error":sys_err,
            "survival_1536":alive(1536),"survival_2048":alive(2048),"coast_survival":alive(2048),
            "first_failure_time":first,"first_failure_type":ftype,
            "initial_residual_1536":r15,"initial_residual_2048":r20,
            "tracked_mass_2048":v(2048,"mass"),"tracked_area_2048":v(2048,"area"),
            "mass_ratio_2048":(v(2048,"mass")/M256 if v(2048,"mass") else None),
            "ROUTE_E_GATE_MET":route_e}
def main():
    law=law_arms()["LAW_16"]; rows=[]; man=[]; t0=time.time()
    for li,L in enumerate(SIZES):
        for k in range(SEEDS_PER):
            seed=970000+li*100+k
            m=np.ascontiguousarray(ic_single_disc(np.random.default_rng(seed),L,P),dtype=np.float64)
            h0=fhash(m,np.full((L,L),0.8),np.zeros((2,L,L)))
            st=prephase(law,m,L); c=largest_bounded(st)
            if c is None or c.wraps_x or c.wraps_y:
                for a in ARMS: rows.append({"L":L,"seed":seed,"arm":a,"t256_status":"T256_INVALID"}); continue
            cs=cells_of(c); M=float(sum(st.m.reshape(-1)[i] for i in cs))
            axis=AXORD[k%4]; masks=build_masks(cs,L,c.centroid_y,c.centroid_x,axis)
            hb=fhash(st.m,st.n,st.b)
            man.append({"L":L,"seed":seed,"axis":axis,"t256_sha256":hb,"M256":M,"t0_sha256":h0})
            cps={a:st.copy() for a in ARMS}
            assert all(fhash(cps[a].m,cps[a].n,cps[a].b)==hb for a in ARMS)
            for a,d in zip(ARMS,DOSES):
                r=branch(law,cps[a],masks,a,d,L,M,cs)
                r.update(L=L,seed=seed,axis=axis,t0_sha256=h0,t256_sha256=hb,t256_status="T256_VALID_TRACK")
                rows.append(r)
            print(f"  L={L} seed={seed} ({len(rows)}/144, {time.time()-t0:.0f}s)",flush=True)
    Path("ab_manifest.json").write_text(json.dumps(man,indent=1))
    f=sorted({kk for r in rows for kk in r})
    with Path("ablation_depth_rows.csv").open("w",newline="") as h:
        w=csv.DictWriter(h,fieldnames=f); w.writeheader(); w.writerows(rows)
    print(f"\n{len(rows)} trajectoires ({time.time()-t0:.0f}s)")
if __name__=="__main__": main()
