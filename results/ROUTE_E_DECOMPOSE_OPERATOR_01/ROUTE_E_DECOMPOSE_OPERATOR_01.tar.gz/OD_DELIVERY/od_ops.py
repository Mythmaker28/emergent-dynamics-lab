from __future__ import annotations
import math
import numpy as np
from od_core import THRESH, MMAX, nbrs, pick_distributed, pick_contiguous

def do_event(state, init_tr, fresh_tr, track, masks, arm, budget, L, res):
    """Un evenement. res = dict des reservoirs {'sink':x,'source':y}."""
    fm=state.m.reshape(-1); fi=init_tr.reshape(-1); ff=fresh_tr.reshape(-1)
    sink_key="sink_contiguous" if "CONTIGUOUS" in arm else "sink_distributed"
    src_key="source_far" if "FAR" in arm else "source_near"
    removed=0.0; injected=0.0; init_out=0.0; fresh_out=0.0
    do_sink = ("SINK_ONLY" in arm) or ("COUPLED" in arm)
    do_src  = ("SOURCE_ONLY" in arm) or ("COUPLED" in arm)
    if do_sink:
        cells=(pick_contiguous if sink_key=="sink_contiguous" else pick_distributed)(
            masks[sink_key],fm,track,L,budget)
        b=budget
        for i in cells:
            if b<=1e-12: break
            take=min(fm[i],b)
            frac=take/fm[i] if fm[i]>0 else 0.0
            io=fi[i]*frac; fo=ff[i]*frac
            fm[i]-=take; fi[i]-=io; ff[i]-=fo
            removed+=take; init_out+=io; fresh_out+=fo; b-=take
        res["sink"]+=removed
    if do_src:
        want = removed if "COUPLED" in arm else budget
        b=want
        for s in masks[src_key]:
            if b<=1e-12: break
            if fm[s]>=THRESH: continue
            if any(n in track for n in nbrs(s,L)): continue
            cap=MMAX-fm[s]
            if cap<=1e-12: continue
            add=min(b,cap); fm[s]+=add; ff[s]+=add; injected+=add; b-=add
        res["source"]-=injected
    lattice_err = 0.0 if "COUPLED" not in arm else abs(removed-injected)
    return {"attempted":budget,"removed":removed,"injected":injected,
            "init_egress":init_out,"transit":fresh_out,
            "deficit":max(0.0,budget-max(removed,injected)),
            "lattice_balance_error":lattice_err}
