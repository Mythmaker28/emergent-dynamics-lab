"""DECOMPOSE_EXCHANGE_OPERATOR_01 — lecture PER_TRACK + reservoirs externes.
Moteur de production et advance_passive_tracer utilises TELS QUELS."""
from __future__ import annotations
import hashlib, math
from collections import deque
import numpy as np
from edlab.substrates.lattice_bond.engine import LatticeBondState, LatticeBondEngine
from edlab.substrates.lattice_bond.instrumentation import DetectorSpec, detect_components, advance_passive_tracer
THRESH=0.45; MINC=3; MMAX=1.0; DET=DetectorSpec(matter_threshold=THRESH,min_cells=MINC)

def comps(state): return detect_components(state,DET,frame=int(state.step))
def largest_bounded(state):
    c=[x for x in comps(state) if not (x.wraps_x or x.wraps_y)]
    return sorted(c,key=lambda x:(-x.area,x.centroid_y,x.centroid_x,x.index))[0] if c else None
def cells_of(c): return set(int(i) for i in c.cells)
def nbrs(i,L):
    y,x=divmod(i,L); return [((y-1)%L)*L+x,((y+1)%L)*L+x,y*L+((x-1)%L),y*L+((x+1)%L)]
def fhash(*a):
    h=hashlib.sha256()
    for x in a:
        h.update(np.ascontiguousarray(x,dtype=np.float64).tobytes(order="C")); h.update(str(x.shape).encode())
    return h.hexdigest()
def advect(tr,pre,ledger,post,dt):
    return advance_passive_tracer(tr,pre,ledger.matter_forward*ledger.matter_scale,
                                  ledger.matter_reverse*ledger.matter_scale,post,dt)

# ---- MESURE PER_TRACK -------------------------------------------------------
def per_track(state, init_tr, fresh_tr, M256):
    """Toutes les metriques individuelles = intersection avec C_t courant."""
    c=largest_bounded(state)
    if c is None:
        return {"track":False,"mass":float("nan"),"area":0,"n_comp":len(comps(state)),
                "init_in_track":float("nan"),"fresh_in_track":float("nan"),
                "initial_residual":float("nan"),"fresh_fraction":float("nan"),
                "cy":float("nan"),"cx":float("nan"),"wrap":False,"cells":set(),"endpoint_defined":False}
    cs=cells_of(c); fm=state.m.reshape(-1); fi=init_tr.reshape(-1); ff=fresh_tr.reshape(-1)
    mass=float(sum(fm[i] for i in cs)); ini=float(sum(fi[i] for i in cs)); fr=float(sum(ff[i] for i in cs))
    return {"track":True,"mass":mass,"area":c.area,"n_comp":len(comps(state)),
            "init_in_track":ini,"fresh_in_track":fr,
            "initial_residual":ini/M256 if M256>0 else float("nan"),
            "fresh_fraction":fr/mass if mass>0 else float("nan"),
            "cy":c.centroid_y,"cx":c.centroid_x,"wrap":bool(c.wraps_x or c.wraps_y),
            "cells":cs,"endpoint_defined":True}

# ---- MASQUES ----------------------------------------------------------------
AXES={"+y":(1,0),"-y":(-1,0),"+x":(0,1),"-x":(0,-1)}
def graph_distance(cells,L):
    """BFS 4-connexe depuis le composant : distance de graphe de chaque site."""
    d=np.full(L*L,-1,dtype=int); q=deque()
    for i in cells: d[i]=0; q.append(i)
    while q:
        i=q.popleft()
        for n in nbrs(i,L):
            if d[n]<0: d[n]=d[i]+1; q.append(n)
    return d
def build_masks(cells,L,cy,cx,axis):
    dy,dx=AXES[axis]; yy,xx=np.mgrid[0:L,0:L]
    proj=((yy-cy)*dy+(xx-cx)*dx).reshape(-1)
    gd=graph_distance(cells,L)
    sink=[i for i in cells if proj[i]>0.0]
    sink_dist=sorted(sink,key=lambda i:(-proj[i],i))
    src_near=sorted([i for i in range(L*L) if gd[i]==2 and proj[i]<0.0],key=lambda i:(proj[i],i))
    src_far =sorted([i for i in range(L*L) if gd[i]>=4 and proj[i]<0.0],key=lambda i:(gd[i],proj[i],i))
    ang=np.arctan2((yy-cy).reshape(-1),(xx-cx).reshape(-1))
    a0=math.atan2(dy,dx)
    sink_cont=sorted(sink,key=lambda i:(abs(((ang[i]-a0+math.pi)%(2*math.pi))-math.pi),i))
    return {"sink_distributed":sink_dist,"sink_contiguous":sink_cont,
            "source_near":src_near,"source_far":src_far}

def pick_distributed(cands,fm,track,L,budget_mass):
    """Priorite gelee: evite d agreger des retraits adjacents quand des candidats non adjacents existent."""
    chosen=[]; used=set()
    for pas in (True,False):
        for i in cands:
            if budget_mass<=1e-12: break
            if i in used or fm[i]<THRESH or i not in track: continue
            if pas and any(n in used for n in nbrs(i,L)): continue
            chosen.append(i); used.add(i); budget_mass-=min(fm[i],budget_mass)
        if budget_mass<=1e-12: break
    return chosen
def pick_contiguous(cands,fm,track,L,budget_mass):
    chosen=[]; b=budget_mass
    for i in cands:
        if b<=1e-12: break
        if fm[i]<THRESH or i not in track: continue
        chosen.append(i); b-=min(fm[i],b)
    return chosen
