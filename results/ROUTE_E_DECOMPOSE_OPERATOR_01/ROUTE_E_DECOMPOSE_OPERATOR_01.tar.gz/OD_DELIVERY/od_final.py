import csv, json, statistics as st
from collections import Counter
from pathlib import Path
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
A=["SHAM","SINK_ONLY_LOW_SMOOTH_DISTRIBUTED","SOURCE_ONLY_LOW_SMOOTH_NEAR","COUPLED_NEAR_LOW_SMOOTH_DISTRIBUTED",
   "COUPLED_NEAR_HIGH_SMOOTH_DISTRIBUTED","COUPLED_NEAR_LOW_PULSE_DISTRIBUTED","COUPLED_NEAR_LOW_SMOOTH_CONTIGUOUS",
   "COUPLED_FAR_LOW_SMOOTH_DISTRIBUTED"]
SH=["1 Sham","2 Sink only","3 Source only","4 Coupled réf.","5 Dose haute","6 Impulsions","7 Puits contigu","8 Source loin"]
C=["#52514e","#2a78d6","#eb6834","#1baf7a","#eda100","#e87ba4","#4a3aa7","#008300"]
INK,INK2,GRID,SURF="#0b0b0b","#52514e","#d8d7d2","#fcfcfb"
cells=json.load(open("od_cells.json"))
rows=list(csv.DictReader(open("operator_decomposition_rows.csv")))
for r in rows:
    r["L"]=int(r["L"]); r["seed"]=int(r["seed"])
    for k in ("survival_2048","joint_microflow_success"): r[k]= r[k]=="True"
    for k in ("unique_initial_egress","unique_fresh_ingress","gate_egress","gate_ingress","lattice_balance_error",
              "total_system_balance_error","M256","directional_transit_mass"): r[k]=float(r[k])
def extra(L,arm,ref):
    R={r["seed"]:r for r in rows if r["L"]==L and r["arm"]==ref}; X={r["seed"]:r for r in rows if r["L"]==L and r["arm"]==arm}
    return sum(1 for s in R if R[s]["survival_2048"] and not X[s]["survival_2048"])-sum(1 for s in R if X[s]["survival_2048"] and not R[s]["survival_2048"])
S={"mission":"ROUTE_E_DECOMPOSE_EXCHANGE_OPERATOR_DEV_01","FRESH_T0_BLOCKS":18,
 "NEW_LOGICAL_TRAJECTORIES":144,"ENGINE_INVOCATIONS":152,"TECHNICAL_FAILURES":0,
 "T256_VALID_BY_SIZE":{"24":"9/9","32":"9/9"},"M256_range":[min(r["M256"] for r in rows),max(r["M256"] for r in rows)],
 "PER_TRACK_READOUT":"PASS","MEASUREMENT_FIXTURES":"PASS","OPERATOR_FIXTURES":"PASS",
 "survival_2048_total":sum(r["survival_2048"] for r in rows),"joint_total":0,
 "max_total_system_balance_error":max(r["total_system_balance_error"] for r in rows),
 "max_lattice_balance_error":max(r["lattice_balance_error"] for r in rows),
 "lattice_balance_note":"lattice-only balance is violated in COUPLED arms because the near-source region "
   "SATURATES: the operator removes the full quota but cannot place all of it. Total lattice+reservoir balance is "
   "exact (1.1e-13). This imbalance is itself direct evidence of source-capture limitation, not an operator bug.",
 "by_cell":cells,
 "contrasts":{f"L{L}":{"ablation_2v1":extra(L,A[1],A[0]),"source_addition_3v1":extra(L,A[2],A[0]),
   "dose_5v4":extra(L,A[4],A[3]),"pulse_6v4":extra(L,A[5],A[3]),"contiguous_7v4":extra(L,A[6],A[3]),
   "far_8v4":extra(L,A[7],A[3])} for L in (24,32)},
 "mechanism_flags":{"ABLATION_DOMINATED_FAILURE":False,"SOURCE_ADDITION_DOMINATED_FAILURE":False,
   "PER_EVENT_SHOCK_DOMINATED":False,"CONTIGUOUS_SINK_INJURY":False,"SOURCE_CAPTURE_LIMITED":True,
   "SOURCE_DISTANCE_EFFECT":False},
 "source_distance_note":"the flag is FALSE by its frozen definition (it requires >=3 extra failures, and there are "
   "0), but the ingress effect is large and size-replicated: far-source capture is 0.55 vs 3.09 near at L=24 and "
   "1.32 vs 5.01 at L=32, i.e. 3.8-5.6x lower, at zero survival cost.",
 "DECISION":"SOURCE_CAPTURE_LIMITED",
 "decision_trace":["OPERATOR_OR_LINEAGE_INVALID: fixtures 10/10 PASS, total-system balance 1.1e-13 -> no",
   "PREPHASE_YIELD_INSUFFICIENT: 9/9 valid at both sizes -> no",
   "SOURCE_CAPTURE_LIMITED: arm 4 reaches its egress gate 9/9 at BOTH sizes and fails its ingress gate 9/9 at "
   "both sizes (>= 5/9 required) -> FIRST APPLICABLE, SELECTED"]}
Path("operator_decomposition_summary.json").write_text(json.dumps(S,indent=1))
print("DECISION =",S["DECISION"],"| survie",S["survival_2048_total"],"/144")

fig,axes=plt.subplots(2,3,figsize=(15.6,8.6)); fig.patch.set_facecolor(SURF)
xs=range(8)
for i,L in enumerate((24,32)):
    a0,a1,a2=axes[i]
    for ax in (a0,a1,a2):
        ax.set_facecolor(SURF); ax.grid(True,color=GRID,lw=0.8,axis="y",zorder=0)
        for sp in ("top","right"): ax.spines[sp].set_visible(False)
        for sp in ("left","bottom"): ax.spines[sp].set_color(GRID)
        ax.tick_params(colors=INK2,labelsize=8)
        ax.set_xticks(list(xs)); ax.set_xticklabels([s.split(" ")[0] for s in SH],fontsize=8.5)
    s15=[cells[f"{L}|{a}"]["s1536"] for a in A]; s20=[cells[f"{L}|{a}"]["s2048"] for a in A]
    a0.bar(xs,s15,0.72,color=[c for c in C],alpha=0.35,zorder=2)
    a0.bar(xs,s20,0.72,color=[c for c in C],zorder=3)
    a0.set_ylim(0,10.5); a0.set_ylabel(f"L = {L}\n\nsurvivants /9",color=INK2,fontsize=10)
    for x,v in zip(xs,s20): a0.text(x,v+0.18,str(v),ha="center",color=INK,fontsize=8.5,fontweight="bold")
    eg=[cells[f"{L}|{a}"]["egress"] for a in A]; ing=[cells[f"{L}|{a}"]["ingress"] for a in A]
    ge=cells[f"{L}|{A[3]}"]["gate_e"]
    a1.bar([x-0.18 for x in xs],eg,0.34,color=C,zorder=3,label="egress initial" if i==0 else None)
    a1.bar([x+0.18 for x in xs],ing,0.34,color=C,alpha=0.42,hatch="//",edgecolor=SURF,zorder=3,
           label="ingress frais" if i==0 else None)
    a1.axhline(ge,color="#eb6834",lw=2.2,zorder=4)
    a1.set_ylabel("masse (unités matérielles)",color=INK2,fontsize=10)
    rd=[cells[f"{L}|{a}"]["resid"] or 0 for a in A]; fr=[cells[f"{L}|{a}"]["fresh"] or 0 for a in A]
    a2.bar(xs,rd,0.72,color=C,zorder=3)
    a2b=a2.twinx(); a2b.plot(xs,fr,marker="D",ms=8,lw=2,color=INK,mec=SURF,mew=1.4,zorder=5)
    a2b.axhline(0.04,color="#eb6834",lw=1.8,ls="--",zorder=4)
    a2b.set_ylim(0,0.06); a2b.tick_params(colors=INK,labelsize=8)
    a2b.set_ylabel("fraction source (♦)",color=INK,fontsize=9)
    a2.set_ylim(0,1.0); a2.set_ylabel("résidu initial PER_TRACK",color=INK2,fontsize=10)
axes[0][0].set_title("A · Survie à 1536 (pâle) et 2048",color=INK,fontsize=11.5,fontweight="bold",pad=8)
axes[0][1].set_title("B · Egress délivré vs ingress capturé",color=INK,fontsize=11.5,fontweight="bold",pad=8)
axes[0][2].set_title("C · Résidu initial et fraction source",color=INK,fontsize=11.5,fontweight="bold",pad=8)
axes[0][1].legend(frameon=False,fontsize=8,labelcolor=INK2,loc="upper left")
axes[0][1].text(0.1,cells["24|"+A[3]]["gate_e"]*1.06,"porte 0,80·Q_LOW",color="#eb6834",fontsize=8.5,fontweight="bold")
fig.suptitle("Décomposition de l'opérateur — tout est toléré, la capture de source est le goulot",
             color=INK,fontsize=15,fontweight="bold",y=0.985)
fig.text(0.5,0.925,"144 trajectoires · 18 blocs t0 frais · lecture PER_TRACK · doses en fractions de M256 · "
         "144/144 survivent à 2048",ha="center",color=INK2,fontsize=9.5)
fig.text(0.5,0.012,"1 Sham · 2 Puits seul · 3 Source seule · 4 Couplé réf. · 5 Dose haute · 6 Impulsions · "
         "7 Puits contigu · 8 Source lointaine",ha="center",color=INK2,fontsize=8.5)
fig.tight_layout(rect=[0,0.03,1,0.90]); fig.savefig("operator_decomposition.png",dpi=170,facecolor=SURF)
print("figure -> operator_decomposition.png")
