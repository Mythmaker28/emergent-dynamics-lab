import json, numpy as np
from od_core import *
from od_ops import do_event
def st(m): return LatticeBondState(np.ascontiguousarray(m,dtype=np.float64),np.full(m.shape,0.8),np.zeros((2,*m.shape)),0)
def blk(L=24):
    m=np.full((L,L),0.1); m[7:17,7:17]=0.9; return np.ascontiguousarray(m,dtype=np.float64)
def run():
    out=[]; L=24; m=blk(L); s=st(m); c=largest_bounded(s); cs=cells_of(c)
    M256=sum(m.reshape(-1)[i] for i in cs)
    # 1 cohorte expulsee mais presente ailleurs -> global > per_track
    init=np.where(m>=THRESH,m,0.0).copy(); fresh=np.zeros_like(m)
    fi=init.reshape(-1); fm=m.reshape(-1)
    victims=sorted(cs)[:20]
    for i in victims: fi[i]=0.0
    far=[i for i in range(L*L) if i not in cs][:20]
    for i in far: fi[i]=0.5
    pt=per_track(s,init,fresh,M256)
    out.append(("1_expulsee_ailleurs", float(init.sum()>pt["init_in_track"]), 1.0))
    # 2 fragmentation: seule la continuation gelee compte
    a=np.full((L,L),0.1); a[3:9,3:9]=0.9; a[15:21,15:21]=0.9
    out.append(("2_fragmentation_track_unique", float(len(comps(st(a)))==2 and largest_bounded(st(a)) is not None), 1.0))
    # 3 disparition puis reapparition
    out.append(("3_disparition_reapparition_continuite", float(largest_bounded(st(np.full((L,L),0.1))) is None), 1.0))
    # 4 provenance fraiche injectee HORS du composant -> ingress 0
    init2=np.where(m>=THRESH,m,0.0).copy(); fr2=np.zeros_like(m); ffr=fr2.reshape(-1)
    outside=[i for i in range(L*L) if i not in cs]
    ffr[outside[0]]=0.6; ffr[outside[1]]=0.6
    out.append(("4_fraiche_hors_composant_ingress0", per_track(s,init2,fr2,M256)["fresh_in_track"], 0.0))
    # 5 fraiche rejoignant le composant -> masse exacte connue
    fr3=np.zeros_like(m); f3=fr3.reshape(-1); tgt=sorted(cs)[:3]
    for i in tgt: f3[i]=0.25
    out.append(("5_fraiche_dans_composant", per_track(s,init2,fr3,M256)["fresh_in_track"], 0.75))
    # 6 transit source->track->sink : le puits retire la masse fraiche du track
    m6=blk(L); s6=st(m6); c6=largest_bounded(s6); cs6=cells_of(c6)
    i6=np.where(m6>=THRESH,m6,0.0).copy(); f6=np.zeros_like(m6); f6.reshape(-1)[sorted(cs6)[0]]=0.30
    mk={"sink_distributed":[sorted(cs6)[0]],"sink_contiguous":[sorted(cs6)[0]],
        "source_near":[],"source_far":[]}
    r=do_event(s6,i6,f6,cs6,mk,"SINK_ONLY_LOW_SMOOTH_DISTRIBUTED",0.30,L,{"sink":0.0,"source":0.0})
    out.append(("6_transit_directionnel", round(r["transit"],10), 0.1))
    # 7 matiere initiale envoyee au puits -> residu initial baisse d une fraction connue
    m7=blk(L); s7=st(m7); c7=largest_bounded(s7); cs7=cells_of(c7); M7=sum(m7.reshape(-1)[i] for i in cs7)
    i7=np.where(m7>=THRESH,m7,0.0).copy(); f7=np.zeros_like(m7)
    before=per_track(s7,i7,f7,M7)["initial_residual"]
    # retrait PARTIEL reparti: aucune cellule ne passe sous le seuil, le track est inchange,
    # donc la baisse du residu doit valoir EXACTEMENT la fraction retiree (test de la MESURE)
    fm7=s7.m.reshape(-1); fi7=i7.reshape(-1)
    for i in sorted(cs7):
        take=0.10*fm7[i]; frac=take/fm7[i]
        fm7[i]-=take; fi7[i]-=fi7[i]*frac
    assert all(fm7[i]>=THRESH for i in cs7) and cells_of(largest_bounded(s7))==cs7
    after=per_track(s7,i7,f7,M7)["initial_residual"]
    out.append(("7_residu_baisse_de_0.10", round(before-after,6), 0.1))
    # 8 changement d etiquette sans transfert
    m8=blk(L); i8=np.where(m8>=THRESH,m8,0.0).copy(); before8=m8.copy()
    lab=i8.copy()
    out.append(("8_relabeling_sans_echange", float(np.abs(m8-before8).sum()), 0.0))
    # 9 bilan separe lattice + reservoirs
    m9=blk(L); s9=st(m9); c9=largest_bounded(s9); cs9=cells_of(c9); M9=sum(m9.reshape(-1)[i] for i in cs9)
    i9=np.where(m9>=THRESH,m9,0.0).copy(); f9=np.zeros_like(m9); rr={"sink":0.0,"source":0.0}
    tot0=float(m9.sum())+rr["sink"]+rr["source"]
    mk9=build_masks(cs9,L,c9.centroid_y,c9.centroid_x,"+x")
    r9=do_event(s9,i9,f9,cs9,mk9,"COUPLED_NEAR_LOW_SMOOTH_DISTRIBUTED",0.05*M9,L,rr)
    tot1=float(s9.m.sum())+rr["sink"]+rr["source"]
    out.append(("9_bilan_total_systeme", round(abs(tot1-tot0),12), 0.0))
    out.append(("9_bilan_lattice_couple", round(r9["lattice_balance_error"],12), 0.0))
    res=[{"fixture":n,"observed":None if o is None else round(float(o),10),"expected":e,
          "PASS":bool(o is not None and abs(float(o)-e)<=1e-9)} for n,o,e in out]
    return res
if __name__=="__main__":
    r=run()
    for x in r: print(f"  {x['fixture']:36s} obs={x['observed']} attendu={x['expected']} -> {'PASS' if x['PASS'] else 'FAIL'}")
    json.dump(r,open("operator_decomposition_fixtures.json","w"),indent=1)
    print("\nTOUTES PASS:",all(x["PASS"] for x in r))
