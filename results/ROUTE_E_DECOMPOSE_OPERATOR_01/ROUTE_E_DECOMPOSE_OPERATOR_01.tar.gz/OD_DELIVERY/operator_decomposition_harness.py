"""DECOMPOSE_EXCHANGE_OPERATOR_01 — 18 blocs x 8 bras = 144 trajectoires logiques."""
from __future__ import annotations
import copy, csv, hashlib, json, math, time
from pathlib import Path
import numpy as np
from od_core import *
from od_ops import do_event
from bridge00_harness import law_arms
from morph02_ic import ic_single_disc

CAD=16; T_B=256; T_F=1536; T_E=2048; P=0.35; SIZES=(24,32); SEEDS_PER=9
ARMS=["SHAM","SINK_ONLY_LOW_SMOOTH_DISTRIBUTED","SOURCE_ONLY_LOW_SMOOTH_NEAR",
      "COUPLED_NEAR_LOW_SMOOTH_DISTRIBUTED","COUPLED_NEAR_HIGH_SMOOTH_DISTRIBUTED",
      "COUPLED_NEAR_LOW_PULSE_DISTRIBUTED","COUPLED_NEAR_LOW_SMOOTH_CONTIGUOUS",
      "COUPLED_FAR_LOW_SMOOTH_DISTRIBUTED"]
AXORD=("+x","-x","+y","-y")
SMOOTH=[272+16*(e-1) for e in range(1,81)]
PULSE=[272+math.floor((e-1)*1264/19) for e in range(1,21)]
def schedule(arm): return PULSE if "PULSE" in arm else SMOOTH
def dose(arm,M): return 0.15*M if "HIGH" in arm else 0.05*M

def prephase(law,m,L):
    eng=LatticeBondEngine(law)
    st=LatticeBondState(m.copy(),np.full((L,L),0.8),np.zeros((2,L,L)),0)
    while int(st.step)<T_B:
        pre=st; st=eng.step(pre).state
    return st

def branch(law,st0,masks,arm,L,M256,cs256):
    eng=LatticeBondEngine(law)
    st=st0.copy()
    init=np.zeros_like(st.m); fi=init.reshape(-1); fm=st.m.reshape(-1)
    for i in cs256: fi[i]=fm[i]                      # provenance initiale enrolee PER_TRACK a t256
    fresh=np.zeros_like(st.m)
    sch=set(schedule(arm)); Q=dose(arm,M256); qe=Q/len(schedule(arm))
    res={"sink":0.0,"source":0.0}; tot0=float(st.m.sum())
    att=rem=inj=0.0; egress=0.0; transit=0.0; defi=0.0; latt_err=0.0; maxfresh=0.0
    first=None; ftype="NONE"; prev=None; snap={}
    t=int(st.step)
    while t<T_E:
        if t in sch:
            pt=per_track(st,init,fresh,M256)
            if arm=="SHAM":
                _=pick_distributed(masks["sink_distributed"],st.m.reshape(-1),pt["cells"],L,qe)
                att+=qe; defi+=qe
            else:
                r=do_event(st,init,fresh,pt["cells"],masks,arm,qe,L,res)
                att+=r["attempted"]; rem+=r["removed"]; inj+=r["injected"]
                egress+=r["init_egress"]; transit+=r["transit"]; defi+=r["deficit"]
                latt_err=max(latt_err,r["lattice_balance_error"])
        pre=st; out=eng.step(pre)
        init=advect(init,pre.m,out.ledger,out.state.m,law.dt)
        fresh=advect(fresh,pre.m,out.ledger,out.state.m,law.dt)
        st=out.state; t=int(st.step)
        if t%CAD==0:
            pt=per_track(st,init,fresh,M256)
            if pt["track"]: maxfresh=max(maxfresh,pt["fresh_in_track"])
            bad=None
            if not pt["track"]: bad="TRACK_LOST_OR_DISSOLVED"
            elif pt["wrap"]: bad="WRAPPING"
            elif prev is not None:
                d=math.hypot(pt["cy"]-prev["cy"],pt["cx"]-prev["cx"]); ar=pt["area"]/max(1,prev["area"])
                if d>3.0 or not (1/3.0<=ar<=3.0): bad="TRACK_LOSS"
            if bad and first is None: first=t; ftype=bad
            if pt["track"]: prev=pt
            if t in (1536,2048): snap[t]=pt
    tot1=float(st.m.sum())+res["sink"]+res["source"]
    sys_err=abs(tot1-tot0)
    def alive(H): return first is None or first>H
    hi="HIGH" in arm
    g_eg = 0.12*M256 if hi else 0.80*dose(arm,M256)
    g_in = 0.12*M256 if hi else 0.80*dose(arm,M256)
    g_res= 0.88 if hi else 0.96
    g_fr = 0.12 if hi else 0.04
    def okH(H):
        s=snap.get(H)
        return bool(s and s["track"] and not s["wrap"] and alive(H)
                    and 0.75*M256<=s["mass"]<=1.25*M256
                    and s["initial_residual"]<=g_res and s["fresh_fraction"]>=g_fr)
    joint = (okH(1536) and okH(2048) and egress>=g_eg and maxfresh>=g_in
             and transit>=0.01*M256 and latt_err<=1e-9 and sys_err<=1e-9 and alive(2048))
    def val(H,k): 
        s=snap.get(H); 
        return s[k] if (s and s["endpoint_defined"] and alive(H)) else None
    return {"arm":arm,"M256":M256,"attempted":att,"realized_sink_removal":rem,"realized_source_injection":inj,
            "unique_initial_egress":egress,"unique_fresh_ingress":maxfresh,"directional_transit_mass":transit,
            "flux_deficit":defi,"lattice_balance_error":latt_err,"total_system_balance_error":sys_err,
            "survival_1536":alive(1536),"survival_2048":alive(2048),"coast_survival":alive(2048),
            "first_failure_time":first,"first_failure_type":ftype,
            "initial_residual_1536":val(1536,"initial_residual"),"initial_residual_2048":val(2048,"initial_residual"),
            "fresh_fraction_1536":val(1536,"fresh_fraction"),"fresh_fraction_2048":val(2048,"fresh_fraction"),
            "tracked_mass_2048":val(2048,"mass"),
            "endpoint_defined_2048":bool(snap.get(2048,{}).get("endpoint_defined") and alive(2048)),
            "gate_egress":g_eg,"gate_ingress":g_in,"joint_microflow_success":joint}

def main():
    law=law_arms()["LAW_16"]; rows=[]; blocks=[]; manifest=[]; t0=time.time()
    for li,L in enumerate(SIZES):
        for k in range(SEEDS_PER):
            seed=950000+li*100+k
            m=np.ascontiguousarray(ic_single_disc(np.random.default_rng(seed),L,P),dtype=np.float64)
            h0=fhash(m,np.full((L,L),0.8),np.zeros((2,L,L)))
            st=prephase(law,m,L)
            c=largest_bounded(st)
            status=("T256_VALID_TRACK" if c is not None and not (c.wraps_x or c.wraps_y)
                    else "T256_WRAPPING" if c is not None else "T256_DISSOLVED")
            blocks.append({"L":L,"seed":seed,"t0_sha256":h0,"t256_status":status})
            if status!="T256_VALID_TRACK":
                for a in ARMS: rows.append({"L":L,"seed":seed,"arm":a,"t0_sha256":h0,"t256_status":status})
                continue
            cs=cells_of(c); M256=float(sum(st.m.reshape(-1)[i] for i in cs))
            axis=AXORD[k%4]; masks=build_masks(cs,L,c.centroid_y,c.centroid_x,axis)
            hb=fhash(st.m,st.n,st.b)
            manifest.append({"L":L,"seed":seed,"axis":axis,"t256_checkpoint_sha256":hb,"M256":M256,
                             "cardinality":len(cs),"masks":{kk:len(vv) for kk,vv in masks.items()}})
            cps={a:st.copy() for a in ARMS}
            assert all(np.array_equal(cps[ARMS[0]].m,cps[a].m) and np.array_equal(cps[ARMS[0]].n,cps[a].n)
                       and np.array_equal(cps[ARMS[0]].b,cps[a].b) for a in ARMS)
            assert all(fhash(cps[a].m,cps[a].n,cps[a].b)==hb for a in ARMS)
            for a in ARMS:
                r=branch(law,cps[a],masks,a,L,M256,cs)
                r.update(L=L,seed=seed,axis=axis,t0_sha256=h0,t256_checkpoint_sha256=hb,
                         t256_status=status,cardinality_256=len(cs))
                rows.append(r)
            print(f"  L={L} seed={seed} ({len(rows)}/144, {time.time()-t0:.0f}s)",flush=True)
    Path("t256_branch_manifest.json").write_text(json.dumps(manifest,indent=1))
    Path("od_blocks.json").write_text(json.dumps(blocks,indent=1))
    f=sorted({kk for r in rows for kk in r})
    with Path("operator_decomposition_rows.csv").open("w",newline="") as h:
        w=csv.DictWriter(h,fieldnames=f); w.writeheader(); w.writerows(rows)
    print(f"\n{len(rows)} trajectoires / {len(blocks)} blocs ({time.time()-t0:.0f}s)")
if __name__=="__main__": main()
