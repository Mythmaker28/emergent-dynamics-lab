"""ROUTE_E_SINGLE_DISC_SOURCE_SINK_DEV_00 — wrapper DEV source-puits.
Moteur de production et advection de traceur utilises TELS QUELS. Aucun fichier de production modifie."""
from __future__ import annotations
import copy, csv, hashlib, json, math, time
from pathlib import Path
import numpy as np
from edlab.substrates.lattice_bond.engine import LatticeBondSpec, LatticeBondState, LatticeBondEngine
from fx_core import (THRESH, DET, components, largest_bounded, cells_of, field_hash,
                     advect, freeze_masks, neighbours, quotas, AXES)
from bridge00_harness import law_arms
from morph02_ic import ic_single_disc

CAD=16; T_BRANCH=256; T_FORCE_END=1536; T_END=2048
EVENTS=list(range(T_BRANCH+CAD, T_FORCE_END+1, CAD))          # 272..1536 = 80 evenements
SIZES=(24,32); N0={24:202,32:358}; P=0.35
LAWS=("BASELINE_SWEEP00","LAW_16"); INTERV=("SHAM","FLOW_2N","FLOW_4N")
AXIS_ORDER=("+x","-x","+y","-y")

def disc_geometry(L):
    N=N0[L]; return math.sqrt(N/math.pi)

def measure(state, coh, fresh, L):
    comp=largest_bounded(state)
    out={"track":comp is not None,"n_comp":len(components(state))}
    if comp is None:
        out.update(mass=0.0,area=0,coh_mass=0.0,fresh_mass=0.0,residual=float("nan"),
                   fresh_frac=float("nan"),cy=float("nan"),cx=float("nan"),
                   wrap=False,compact=float("nan"))
        return out,set()
    cs=cells_of(comp); fm=state.m.reshape(-1); fc=coh.reshape(-1); ff=fresh.reshape(-1)
    mass=float(sum(fm[i] for i in cs)); cm=float(sum(fc[i] for i in cs)); fmm=float(sum(ff[i] for i in cs))
    out.update(mass=mass,area=comp.area,coh_mass=cm,fresh_mass=fmm,
               residual=cm/mass if mass>0 else float("nan"),
               fresh_frac=fmm/mass if mass>0 else float("nan"),
               cy=comp.centroid_y,cx=comp.centroid_x,
               wrap=bool(comp.wraps_x or comp.wraps_y),
               compact=4*math.pi*comp.area/max(1e-9,(comp.radius_gyration+1e-9)**2*4*math.pi))
    return out,cs

def exchange(state, coh, fresh, track_cells, sink_idx, src_idx, q, L, m_max=1.0):
    """Un evenement. Retire jusqu a q cellules du puits (dans le track) et place EXACTEMENT
    la meme masse dans des sites source vacants et non adjacents au track, en respectant la
    capacite m_max. Conservation exacte par construction. Jamais de rattrapage d un deficit."""
    fm=state.m.reshape(-1); fc=coh.reshape(-1); ff=fresh.reshape(-1)
    sinks=[i for i in sink_idx if fm[i]>=THRESH and i in track_cells]
    srcs=[]
    for t in src_idx:
        if fm[t]>=THRESH: continue
        if any(nb in track_cells for nb in neighbours(t,L)): continue
        if m_max-fm[t] <= 1e-12: continue
        srcs.append(t)
    removed=0.0; injected=0.0; egress_cells=0; done=0; sp=0
    for i in sinks[:q]:
        payload=float(fm[i]); remaining=payload
        placed=0.0
        while remaining>1e-12 and sp<len(srcs):
            t=srcs[sp]; cap=m_max-fm[t]
            if cap<=1e-12: sp+=1; continue
            take=min(remaining,cap)
            fm[t]+=take; ff[t]+=take; placed+=take; remaining-=take
            if m_max-fm[t]<=1e-12: sp+=1
        if placed<=1e-12: break
        frac_out=placed/payload
        fc[i]*=(1.0-frac_out); ff[i]*=(1.0-frac_out); fm[i]=payload-placed
        removed+=placed; injected+=placed; done+=1
        if fm[i]<THRESH: egress_cells+=1
    return {"attempted":q,"realized":done,"deficit":q-done,"removed":removed,"injected":injected,
            "balance_error":abs(removed-injected),"sink_cand":len(sinks),"src_cand":len(srcs),
            "egress_cells":egress_cells}

def run_trajectory(law_name, law, interv, state, coh, fresh, L, sink_idx, src_idx, rng_int):
    eng=LatticeBondEngine(law); Q={"SHAM":2*N0[L],"FLOW_2N":2*N0[L],"FLOW_4N":4*N0[L]}[interv]
    qs=quotas(Q); ev=dict(zip(EVENTS,qs))
    N0m=None; rows=[]; hist=[]
    unique_egress=0; max_fresh=0.0; att=0; rea=0; defi=0; balerr=0.0
    mean_cell=None; first_fail=None; fail_type="NONE"; prev=None
    t=int(state.step)
    m0,_=measure(state,coh,fresh,L); N0m=m0["mass"]; mean_cell=N0m/max(1,m0["area"])
    while t < T_END:
        # intervention AVANT le pas, exactement aux instants geles
        if t in ev:
            _,cs=measure(state,coh,fresh,L)
            r=exchange(state,coh,fresh,cs,sink_idx,src_idx,ev[t],L) if interv!="SHAM" else {"attempted":ev[t],"realized":0,"deficit":ev[t],"removed":0.0,"injected":0.0,"balance_error":0.0,"sink_cand":0,"src_cand":0,"egress_cells":0}
            rng_int.random()                              # RNG d intervention consomme identiquement
            att+=r["attempted"]; rea+=r["realized"]; defi+=r["deficit"]; balerr=max(balerr,r["balance_error"])
            unique_egress+=r["egress_cells"]
        pre=state
        res=eng.step(pre)
        coh=advect(coh,pre.m,res.ledger,res.state.m,law.dt)
        fresh=advect(fresh,pre.m,res.ledger,res.state.m,law.dt)
        state=res.state; t=int(state.step)
        if t%CAD==0:
            mm,cs=measure(state,coh,fresh,L)
            if mm["track"]: max_fresh=max(max_fresh,mm["fresh_mass"])
            bad=None
            if not mm["track"]: bad="TRACK_LOST_OR_DISSOLVED"
            elif mm["wrap"]: bad="WRAPPING"
            elif prev is not None:
                disp=math.hypot(mm["cy"]-prev["cy"],mm["cx"]-prev["cx"])
                ratio=mm["area"]/max(1,prev["area"])
                if disp>3.0 or not (1/3.0<=ratio<=3.0): bad="TRACK_LOSS"
            if bad and first_fail is None: first_fail=t; fail_type=bad
            prev=mm if mm["track"] else prev
            hist.append((t,mm))
    return {"N0_mass":N0m,"mean_cell":mean_cell,"hist":hist,"first_fail":first_fail,
            "fail_type":fail_type,"attempted":att,"realized":rea,"deficit":defi,
            "balance_error":balerr,"unique_egress_cells":unique_egress,
            "unique_ingress_cells":max_fresh/mean_cell if mean_cell else 0.0}
