"""Driver: prephase partagee 0->256, branchement hache, 3 interventions, 144 trajectoires."""
from __future__ import annotations
import copy, csv, hashlib, json, math, time
from pathlib import Path
import numpy as np
from edlab.substrates.lattice_bond.engine import LatticeBondState, LatticeBondEngine
from fx_core import THRESH, freeze_masks, field_hash, advect, largest_bounded, cells_of
from forced_exchange_harness import (measure, exchange, N0, P, SIZES, LAWS, INTERV,
                                     EVENTS, CAD, T_BRANCH, T_FORCE_END, T_END, AXIS_ORDER)
from forced_exchange_harness import quotas
from bridge00_harness import law_arms
from morph02_ic import ic_single_disc

def prephase(law, m, L):
    eng=LatticeBondEngine(law)
    st=LatticeBondState(m.copy(), np.full((L,L),0.8), np.zeros((2,L,L)), 0)
    coh=np.where(m>=THRESH,m,0.0).copy(); fresh=np.zeros_like(m)
    while int(st.step)<T_BRANCH:
        pre=st; res=eng.step(pre)
        coh=advect(coh,pre.m,res.ledger,res.state.m,law.dt)
        fresh=advect(fresh,pre.m,res.ledger,res.state.m,law.dt)
        st=res.state
    return st,coh,fresh

def branch(law, st, coh, fresh, interv, L, sink, src, N0m, mean_cell):
    eng=LatticeBondEngine(law)
    Q={"SHAM":2*N0[L],"FLOW_2N":2*N0[L],"FLOW_4N":4*N0[L]}[interv]
    ev=dict(zip(EVENTS,quotas(Q))); rng=np.random.default_rng(7)
    st=st.copy(); coh=coh.copy(); fresh=fresh.copy()
    att=rea=defi=0; balerr=0.0; egress=0; maxfresh=0.0
    first_fail=None; fail="NONE"; prev=None; snap={}
    t=int(st.step)
    while t<T_END:
        if t in ev:
            if interv=="SHAM":
                _,_=measure(st,coh,fresh,L); rng.random()
                att+=ev[t]; defi+=ev[t]
            else:
                _,cs=measure(st,coh,fresh,L)
                r=exchange(st,coh,fresh,cs,sink,src,ev[t],L); rng.random()
                att+=r["attempted"]; rea+=r["realized"]; defi+=r["deficit"]
                balerr=max(balerr,r["balance_error"]); egress+=r["egress_cells"]
        pre=st; res=eng.step(pre)
        coh=advect(coh,pre.m,res.ledger,res.state.m,law.dt)
        fresh=advect(fresh,pre.m,res.ledger,res.state.m,law.dt)
        st=res.state; t=int(st.step)
        if t%CAD==0:
            mm,_=measure(st,coh,fresh,L)
            if mm["track"]: maxfresh=max(maxfresh,mm["fresh_mass"])
            bad=None
            if not mm["track"]: bad="TRACK_LOST_OR_DISSOLVED"
            elif mm["wrap"]: bad="WRAPPING"
            elif prev is not None:
                d=math.hypot(mm["cy"]-prev["cy"],mm["cx"]-prev["cx"]); ar=mm["area"]/max(1,prev["area"])
                if d>3.0 or not (1/3.0<=ar<=3.0): bad="TRACK_LOSS"
            if bad and first_fail is None: first_fail=t; fail=bad
            if mm["track"]: prev=mm
            if t in (256,1536,2048): snap[t]=mm
    ing=maxfresh/mean_cell if mean_cell else 0.0
    def alive(H): return first_fail is None or first_fail>H
    def ok(H):
        s=snap.get(H)
        return bool(s and s["track"] and not s["wrap"] and alive(H)
                    and 0.5*N0m<=s["mass"]<=1.5*N0m
                    and s["residual"]<=0.20 and s["fresh_frac"]>=0.80)
    joint1536 = ok(1536) and ing>=0.8*N0[L] and egress>=0.8*N0[L] and balerr<=1e-9
    joint2048 = joint1536 and ok(2048)
    return {"attempted":att,"realized":rea,"deficit":defi,"balance_error":balerr,
            "unique_egress_cells":egress,"unique_ingress_cells":ing,
            "first_failure_time":first_fail,"first_failure_type":fail,
            "survival_256":alive(256),"survival_1536":alive(1536),"survival_2048":alive(2048),
            "coast_survival":alive(2048) and alive(1536),
            "residual_1536":snap.get(1536,{}).get("residual"),"residual_2048":snap.get(2048,{}).get("residual"),
            "fresh_frac_1536":snap.get(1536,{}).get("fresh_frac"),"fresh_frac_2048":snap.get(2048,{}).get("fresh_frac"),
            "mass_1536":snap.get(1536,{}).get("mass"),"mass_2048":snap.get(2048,{}).get("mass"),
            "joint_exchange_persistence_1536":joint1536,"joint_exchange_persistence_2048":joint2048}

def main():
    laws=law_arms(); rows=[]; blocks=[]; t0=time.time()
    for li,L in enumerate(SIZES):
        r=math.sqrt(N0[L]/math.pi)
        for k in range(12):
            seed=940000+li*100+k
            m=np.ascontiguousarray(ic_single_disc(np.random.default_rng(seed),L,P),dtype=np.float64)
            c0=largest_bounded(LatticeBondState(m,np.full((L,L),0.8),np.zeros((2,L,L)),0))
            axis=AXIS_ORDER[k%4]
            sink,src=freeze_masks(L,c0.centroid_y,c0.centroid_x,r,axis)
            h0=field_hash(m,np.full((L,L),0.8),np.zeros((2,L,L)))
            blocks.append({"L":L,"seed":seed,"axis":axis,"initial_microstate_sha256":h0,
                           "n_cells_t0":int((m>=THRESH).sum()),"sink_cells":len(sink),"source_cells":len(src)})
            for law_name in LAWS:
                st,coh,fresh=prephase(laws[law_name],m,L)
                m256,cs=measure(st,coh,fresh,L)
                hb=field_hash(st.m,st.n,st.b,coh,fresh)
                status=("T256_VALID_TRACK" if (m256["track"] and not m256["wrap"]) else
                        "T256_DISSOLVED" if not m256["track"] else "T256_WRAPPING")
                N0m=m256["mass"]; mean_cell=N0m/max(1,m256["area"])
                cps={iv:(st.copy(),coh.copy(),fresh.copy()) for iv in INTERV}
                a=cps[INTERV[0]]; ok=all(np.array_equal(getattr(a[0],f),getattr(cps[iv][0],f))
                                          for iv in INTERV for f in ("m","n","b"))
                assert ok and all(field_hash(cps[iv][0].m,cps[iv][0].n,cps[iv][0].b,cps[iv][1],cps[iv][2])==hb for iv in INTERV)
                for iv in INTERV:
                    s2,c2,f2=cps[iv]
                    res=branch(laws[law_name],s2,c2,f2,iv,L,sink,src,N0m,mean_cell) if status=="T256_VALID_TRACK" else {}
                    row={"L":L,"seed":seed,"axis":axis,"law":law_name,"intervention":iv,
                         "initial_microstate_sha256":h0,"t256_checkpoint_sha256":hb,
                         "t256_status":status,"t256_mass":N0m,"t256_area":m256["area"],
                         "t256_residual":m256["residual"], **res}
                    rows.append(row)
            print(f"  L={L} seed={seed} ({len(rows)}/144, {time.time()-t0:.0f}s)",flush=True)
    Path("forced_exchange_blocks.json").write_text(json.dumps(blocks,indent=1))
    f=sorted({k for r in rows for k in r})
    with Path("forced_exchange_rows.csv").open("w",newline="") as h:
        w=csv.DictWriter(h,fieldnames=f); w.writeheader(); w.writerows(rows)
    print(f"\n{len(rows)} trajectoires / {len(blocks)} blocs ({time.time()-t0:.0f}s)")

if __name__=="__main__": main()
