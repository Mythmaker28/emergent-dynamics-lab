"""DEV wrapper source-puits. AUCUNE modification du moteur de production.
Utilise LatticeBondEngine.step et advance_passive_tracer tels quels."""
from __future__ import annotations
import hashlib, math
import numpy as np
from edlab.substrates.lattice_bond.engine import LatticeBondSpec, LatticeBondState, LatticeBondEngine
from edlab.substrates.lattice_bond.instrumentation import (DetectorSpec, detect_components,
                                                           advance_passive_tracer)
THRESH=0.45; MINC=3; MAXDISP=3.0; MAXAR=3.0
DET=DetectorSpec(matter_threshold=THRESH, min_cells=MINC)

def occupied(m): return m>=THRESH

def components(state):
    return detect_components(state, DET, frame=int(state.step))

def largest_bounded(state):
    c=[x for x in components(state) if not (x.wraps_x or x.wraps_y)]
    if not c: return None
    return sorted(c,key=lambda x:(-x.area,x.centroid_y,x.centroid_x,x.index))[0]

def cells_of(comp): return set(int(c) for c in comp.cells)

def field_hash(*arrays):
    h=hashlib.sha256()
    for a in arrays:
        h.update(np.ascontiguousarray(a,dtype=np.float64).tobytes(order="C"))
        h.update(str(a.dtype).encode()); h.update(str(a.shape).encode())
    return h.hexdigest()

def advect(tracer, pre, ledger, post, dt):
    return advance_passive_tracer(tracer, pre, ledger.matter_forward*ledger.matter_scale,
                                  ledger.matter_reverse*ledger.matter_scale, post, dt)

# ---------------------------------------------------------------- masques geles
AXES={"+y":(1,0),"-y":(-1,0),"+x":(0,1),"-x":(0,-1)}

def freeze_masks(L, cy, cx, r, axis):
    """SINK = moitie aval du disque initial. SOURCE = bande amont hors disque,
    a distance >= r+2 du centre. Coordonnees ABSOLUES, jamais recentrees."""
    dy,dx=AXES[axis]
    yy,xx=np.mgrid[0:L,0:L]
    proj=(yy-cy)*dy+(xx-cx)*dx
    dist2=(yy-cy)**2+(xx-cx)**2
    inside=dist2<=r*r
    sink=inside&(proj>0.0)
    band=(~inside)&(proj< -r*0.20)          # demi-plan amont entier hors disque, gele avant run
    sink_idx=sorted(np.flatnonzero(sink.reshape(-1)).tolist(),
                    key=lambda i:(-proj.reshape(-1)[i], i))          # priorite gelee: le plus aval
    src_idx=sorted(np.flatnonzero(band.reshape(-1)).tolist(),
                   key=lambda i:(proj.reshape(-1)[i], i))            # priorite gelee: le plus proche du disque
    return sink_idx, src_idx

def neighbours(i,L):
    y,x=divmod(i,L)
    return [((y-1)%L)*L+x, ((y+1)%L)*L+x, y*L+((x-1)%L), y*L+((x+1)%L)]

def quotas(Q, n_events=80):
    return [math.floor(e*Q/n_events)-math.floor((e-1)*Q/n_events) for e in range(1,n_events+1)]
