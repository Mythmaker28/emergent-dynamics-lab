# ROUTE_E_MORPHOLOGY_AT_FROZEN_FRONTIER_02 — rapport

**2026-08-07** · 72 blocs initiaux uniques · 144 trajectoires appariées · horizon 2048 ·
0 `INITIAL_GATE_FAIL` · 0 échec technique · 0 raffinement · 0 fichier de production modifié.

---

## 1. Ce qui a été testé

Au niveau frontière gelé **`p_D = 0,35`** (le seul où un survivant ait jamais été observé, et
qui conserve 12/12 blocs admissibles aux deux tailles), trois morphologies initiales à
**cardinalité construite égale** — 202 cellules à L=24, 358 à L=32, sur un fond strictement
sous-seuil — rejouées chacune sous `BASELINE_SWEEP00` et `LAW_16` :

| Morphologie | composants à t0 (médiane) | occupation réalisée |
|---|---|---|
| `RANDOM_IID` (carte de quantile de production) | **22 / 38** | 0,344 / 0,343 |
| `SINGLE_DISC` | **1 / 1** | 0,351 / 0,350 |
| `COMPACT_ISLANDS` | **3 / 3** | 0,351 / 0,350 |

Appariement identique au parent : `m`, `n`, `b` hachés, deux copies profondes,
`np.array_equal` champ par champ **avant le premier pas**, re-hachage asserté, un seul
`initial_microstate_sha256` écrit dans les deux bras. La **loi** est appariée ; la
**morphologie** est inter-blocs par nécessité (des morphologies différentes *sont* des
microétats différents). Graines fraîches `DEV_MORPHOLOGY_FRONTIER_02`, disjointes de toutes
les précédentes.

## 2. Résultat principal — la morphologie décide

Survivants à H=2048, sur 12 blocs par cellule :

| Morphologie | L=24 Baseline | L=24 LAW_16 | L=32 Baseline | L=32 LAW_16 |
|---|---|---|---|---|
| `RANDOM_IID` | 0 | 2 | 0 | 0 |
| **`SINGLE_DISC`** | **6** | **12** | **12** | **12** |
| `COMPACT_ISLANDS` | 2 | 3 | 0 | 1 |

À **masse totale attendue identique**, un disque unique persiste jusqu'à 2048 dans
**42 cas sur 48** ; la même matière dispersée i.i.d. persiste dans 2 cas sur 48. Ce n'est ni la
densité ni la loi : c'est **l'organisation spatiale initiale**.

```
DECISION = MORPHOLOGY_RESCUES_SURVIVAL
```

## 3. Le revers, et il est décisif

**Les survivants ne remplacent pas leur matière.**

| Morphologie | L | bras | n surv. | résidu médian | plancher médian | résidu − plancher |
|---|---|---|---|---|---|---|
| `SINGLE_DISC` | 24 | Baseline | 6 | 0,721 | 0,664 | **+0,056** |
| `SINGLE_DISC` | 24 | LAW_16 | 12 | **0,876** | 0,669 | **+0,207** |
| `SINGLE_DISC` | 32 | Baseline | 12 | 0,789 | 0,670 | **+0,118** |
| `SINGLE_DISC` | 32 | LAW_16 | 12 | **0,907** | 0,670 | **+0,237** |

La porte gelée demande `cohort_residual ≤ 0,20`. Les survivants sont à **0,72–0,91**, et
**au-dessus de leur propre plancher de fraction enrôlée** : ils ne se contentent pas de ne pas
atteindre la porte, ils retiennent *plus* que ce que le mélange global imposerait.

Autrement dit : **ce qui persiste, persiste en n'échangeant pas.** Route E exige une
persistance **avec** ≤ 20 % de rétention. Dans ce substrat et à ces paramètres, persistance et
remplacement matériel sont **en tension**, et l'objet obtenu est exactement le
*static occupancy null* que `AGENTS.md` nomme comme null attendu — pas un sauvetage.

**LAW_16 aggrave la tension.** Sur les disques survivant dans les deux bras, elle augmente la
rétention dans **18 paires sur 18** : delta médian **+0,151** à L=24 (test des signes
unilatéral **p = 0,0156**) et **+0,119** à L=32 (**p = 0,00024**). La seule loi retenue comme
candidate éloigne donc le système de la porte de résidu.

## 4. Réplication du seul signal positif du projet

La cellule `RANDOM_IID / L=24 / LAW_16` avait donné 3 survivants sur 12 à la mission
précédente (graines 920000-920011). Sur **12 graines fraîches** (930000-930011) : **2 sur 12**,
baseline 0 sur 12.

```
verdict = NOT_REPLICATED_AT_THE_PRE_REGISTERED_BAR   (barre : >= 3)
```

Le cumul des deux missions à cette cellule est **5/24 sous LAW_16 contre 0/24 sous BASELINE**.
C'est une association réelle et cohérente en direction, mais elle **n'atteint pas la barre
préenregistrée** et je ne la promeus pas. Un échec de réplication est un résultat recevable ;
il ne déclenche aucune mission d'audit.

## 5. Ce que cela n'établit pas

Aucune sortie n'établit `INDIVIDUATION`, `IDENTITY`, `BOUNDED_ENTITY`, `GLOBAL_IDENTITY`,
`DISTAL_BEHAVIOR`, `GRADED_METROLOGY` ni `TURING`, et rien ici ne réfute Route E ni
`NONMERGING_CONFIRM_02`. Un disque qui dure n'est pas une entité : il n'a passé aucune porte
de remplacement, et sa persistance est compatible avec la simple occupation statique.

Limitations déclarées : un seul niveau d'occupation (0,35) ; deux tailles ; `LAW_16`
sélectionnée post hoc au DEV parent ; la continuité de piste reste un **proxy déclaré**
(`ComponentMeasurement` ne porte pas de `track_id`) ; les seuils 0,01 / 0,05 / 0,20 sont
imbriqués et ne comptent pas pour trois réplications.

## 6. Ce que je retiens pour la suite

La question utile n'est plus « à quelle densité, sous quelle loi ». Les données disent
maintenant : **une structure bornée persiste quand elle est compacte, et elle persiste
précisément parce qu'elle n'échange pas.** La prochaine expérience qui vaut le coût est donc
celle qui cherche un régime où un composant compact **échange** sa matière — c'est-à-dire un
gradient ou un flux imposé traversant le disque — et non un balayage de plus sur la densité
ou sur la famille de lois.


---

## Corrections apportées en place le 2026-08-07 (mission SOURCE_SINK_00)

1. **Erreur arithmétique corrigée.** Le total `SINGLE_DISC` était écrit « 36 cas sur 48 ».
   Les lignes authentiques donnent **6 + 12 + 12 + 12 = 42/48**. Totaux recalculés depuis
   `morph02_rows.csv` : `RANDOM_IID 2/48`, `SINGLE_DISC 42/48`, `COMPACT_ISLANDS 6/48`,
   **50 survivants au total**. Le protocole gelé et les lignes brutes sont inchangés.
2. **Portée de la cardinalité corrigée.** « Cardinalité exactement égale entre morphologies »
   était trop fort : `SINGLE_DISC` et `COMPACT_ISLANDS` valent exactement 202/576 et 358/1024
   pour chaque graine, mais `RANDOM_IID` est binomial et varie de **0,302 à 0,382** (L=24) et
   **0,325 à 0,361** (L=32). C'est l'origine exacte de la plage « 0,343–0,351 » du résumé.
   La cardinalité est exacte entre les deux morphologies construites, et égale seulement
   **en espérance** pour le bras aléatoire.
3. **Portée de l'appariement précisée.** Les deux bras de LOI d'un même microétat sont
   bit-identiques à t=0 (hash + `array_equal`). Les trois **morphologies ne sont pas**
   `array_equal` et ne sont pas appariées : elles sont seulement équilibrées par indice de graine.
4. **Formulation canonique du résultat.** À retenir :
   `SINGLE_DISC_INITIALIZATION_STRONGLY_INCREASES_PERSISTENCE_RELATIVE_TO_EQUAL_EXPECTED_MASS_RANDOM_IID_IN_THIS_DEV`
   — et **non** « la compacité seule cause la survie ». Le disque met toute sa masse dans **un**
   composant quand le champ aléatoire la répartit sur 22–38, et le tracker ne suit que le plus
   grand : nombre de composants et fraction suivie sont **confondus** avec la compacité.
5. **Rétention LAW_16 conditionnée.** Les 18 paires sont exactement les co-survivants
   (6 à L=24, 12 à L=32). Formulation correcte : *parmi les co-survivants appariés, LAW_16 est
   associée à une cohorte retenue plus grande ; l'analyse est conditionnée à la survie conjointe*
   — ce n'est pas une preuve générale que LAW_16 empêche le renouvellement.
