"""Les 8 fixtures obligatoires. Ce ne sont PAS des mondes moteur."""
from __future__ import annotations
import json, math
import numpy as np
from edlab.substrates.lattice_bond.engine import LatticeBondState
from fx_core import THRESH, DET, components, largest_bounded, cells_of

def disc(L,cy,cx,r,val=0.9,bg=0.1,rng=None):
    yy,xx=np.mgrid[0:L,0:L]; m=np.full((L,L),bg)
    m[(yy-cy)**2+(xx-cx)**2<=r*r]=val
    return np.ascontiguousarray(m,dtype=np.float64)

def st(m): return LatticeBondState(m,np.full(m.shape,0.8),np.zeros((2,*m.shape)),0)

def residual(m,tracer):
    s=st(m); comp=largest_bounded(s)
    if comp is None: return None
    cs=cells_of(comp); fm=m.reshape(-1); ft=tracer.reshape(-1)
    mass=sum(fm[i] for i in cs); coh=sum(ft[i] for i in cs)
    return coh/mass if mass>0 else None

def run():
    out=[]; L=24; r=6.0
    m=disc(L,12,12,r); T=np.where(m>=THRESH,m,0.0)
    out.append(("1_disque_immobile",residual(m,T),1.0))
    m2=np.roll(np.roll(m,3,0),2,1); T2=np.roll(np.roll(T,3,0),2,1)
    out.append(("2_translation_rigide",residual(m2,T2),1.0))
    # bloc EXACT de 100 cellules: 50% et 80% sont alors exacts au flottant pres
    blk=np.full((L,L),0.1); blk[7:17,7:17]=0.9; blk=np.ascontiguousarray(blk,dtype=np.float64)
    Tb=np.where(blk>=THRESH,blk,0.0)
    csb=sorted(cells_of(largest_bounded(st(blk))))
    assert len(csb)==100, f"le bloc doit faire exactement 100 cellules, il en fait {len(csb)}"
    for frac,exp,tag in ((0.5,0.5,"3"),(0.8,0.2,"4"),(1.0,0.0,"5")):
        k=int(round(frac*len(csb))); T3=Tb.copy().reshape(-1)
        for i in csb[:k]: T3[i]=0.0                     # remplacement physique: matiere non marquee
        out.append((f"{tag}_remplacement_{int(frac*100)}pc", residual(blk,T3.reshape(L,L)), exp))
    # 6 relabeling seul: on renomme sans muter la matiere -> echange physique nul
    T6=T.copy()
    out.append(("6_relabeling_seul", float(np.abs(T6-T).sum()), 0.0))
    # 7 dissolution puis reapparition du meme masque -> continuite fausse
    empty=np.full((L,L),0.1)
    seq=[m,empty,m]
    cont=all(largest_bounded(st(x)) is not None for x in seq)
    out.append(("7_dissolution_puis_reapparition", float(cont), 0.0))
    # 8 fragmentation/fusion sous la regle gelee du tracker
    a=disc(L,8,8,3.0); b=disc(L,16,16,3.0); frag=np.maximum(a,b)
    n_frag=len(components(st(frag))); n_one=len(components(st(disc(L,12,12,5.0))))
    out.append(("8_fragmentation_2_composants", float(n_frag), 2.0))
    out.append(("8_fusion_1_composant", float(n_one), 1.0))
    res=[]
    for name,obs,exp in out:
        ok = obs is not None and abs(float(obs)-exp)<=1e-9
        res.append({"fixture":name,"observed":None if obs is None else round(float(obs),12),
                    "expected":exp,"PASS":bool(ok)})
    return res

if __name__=="__main__":
    r=run()
    for x in r: print(f"  {x['fixture']:34s} obs={x['observed']} attendu={x['expected']} -> {'PASS' if x['PASS'] else 'FAIL'}")
    json.dump(r,open("forced_exchange_fixtures.json","w"),indent=1)
    print("\nTOUTES PASS:",all(x["PASS"] for x in r))
