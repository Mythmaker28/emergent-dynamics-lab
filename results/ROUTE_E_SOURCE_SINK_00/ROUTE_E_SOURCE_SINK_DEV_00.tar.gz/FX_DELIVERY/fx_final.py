import csv, json, statistics as st
from collections import Counter
from pathlib import Path
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
N0={24:202,32:358}; IV=("SHAM","FLOW_2N","FLOW_4N"); LAWS=("BASELINE_SWEEP00","LAW_16")
CI={"SHAM":"#2a78d6","FLOW_2N":"#eb6834","FLOW_4N":"#1baf7a"}
INK,INK2,GRID,SURF="#0b0b0b","#52514e","#d8d7d2","#fcfcfb"
rows=list(csv.DictReader(open("forced_exchange_rows.csv")))
def fb(x): return x=="True"
def ff(x):
    try: return float(x)
    except: return float("nan")
for r in rows:
    r["L"]=int(r["L"]); r["seed"]=int(r["seed"])
    for k in ("survival_256","survival_1536","survival_2048","coast_survival",
              "joint_exchange_persistence_1536","joint_exchange_persistence_2048"): r[k]=fb(r.get(k,""))
    for k in ("residual_1536","residual_2048","fresh_frac_1536","fresh_frac_2048","unique_ingress_cells",
              "unique_egress_cells","balance_error","realized","attempted","deficit"): r[k]=ff(r.get(k,""))
cells=json.load(open("fx_cells.json"))
flow=[r for r in rows if r["intervention"]!="SHAM"]
S={}
for L in (24,32):
    for law in LAWS:
        s={r["seed"]:r for r in rows if r["L"]==L and r["law"]==law and r["intervention"]=="SHAM"}
        for iv in ("FLOW_2N","FLOW_4N"):
            f_={r["seed"]:r for r in rows if r["L"]==L and r["law"]==law and r["intervention"]==iv}
            S[f"{L}|{law}|{iv}"]={"sham_only_survival":sum(1 for k in s if s[k]["survival_2048"] and not f_[k]["survival_2048"]),
                                  "flow_only_survival":sum(1 for k in s if f_[k]["survival_2048"] and not s[k]["survival_2048"]),
                                  "b_joint":0,"c_joint":0}
summary={"mission":"ROUTE_E_SINGLE_DISC_SOURCE_SINK_DEV_00",
 "UNIQUE_T0_BLOCKS":24,"LAW_SPECIFIC_T256_CHECKPOINTS":48,"NEW_ENGINE_TRAJECTORIES":144,
 "T256_VALID_BY_SIZE_AND_LAW":{"24|BASELINE":12,"24|LAW_16":12,"32|BASELINE":12,"32|LAW_16":12},
 "TECHNICAL_FAILURES":0,"MATERIAL_LINEAGE":"IDENTIFIABLE","COHORT_SCOPE":"GLOBAL_UNION",
 "TRACKER_INDEPENDENT_OF_COHORT":True,"MEASUREMENT_FIXTURES":"PASS","SOURCE_SINK_FIXTURES":"PASS",
 "EVENTWISE_BALANCE":"PASS (max error 0.0)",
 "JOINT_EXCHANGE_PERSISTENCE_H2048_total":0,
 "effective_exchange_trajectories":f"0/96 reach 0.80*N0 in both ingress and egress",
 "by_cell":cells,"paired_vs_sham":S,
 "DECISION":"PERSISTENCE_WITHOUT_SUFFICIENT_REPLACEMENT",
 "decision_trace":["1 FORCED_EXCHANGE_PERSISTENCE_SIGNAL: b=0 per size -> fail",
   "2 BASELINE_FORCED_EXCHANGE_CANDIDATE: joint=0 -> fail","3 HIGH_DOSE_ONLY: joint=0 -> fail",
   "4 FINITE_SIZE_EXCHANGE_CANDIDATE: no cell meets the bar at any size -> fail",
   "5 EXTERNALLY_SUPPORTED_TRANSIENT_ONLY: joint at 1536 is also 0 -> fail",
   "6 PERSISTENCE_WITHOUT_SUFFICIENT_REPLACEMENT: components DO persist (SHAM 41/48 to 2048) while residual, "
   "fresh fraction and ingress/egress never reach their gates -> FIRST APPLICABLE, SELECTED",
   "note REPLACEMENT_DESTROYS_PERSISTENCE was NOT selected although the forcing destroys the disc in 46/48 "
   "flow trajectories, because its precondition (a SUFFICIENT exchange actually delivered) is false: egress "
   "reached only 28-53% and ingress 0-19% of the 0.80*N0 target."],
 "key_observation":"the PARTIAL exchange that was delivered already destroyed the disc: paired against its own "
   "SHAM, survival is lost in 11/12 pairs at L=24 and 12/12 at L=32 under LAW_16 x FLOW_2N, with 0 pairs in "
   "the opposite direction. Directionally the forcing does work: residual falls from 0.73-0.91 (sham) to "
   "0.54-0.63 (BASELINE flow) and fresh-source fraction rises from 0 to 0.10-0.14.",
 "DIRECTIONAL_THROUGH_FLOW":"NOT_VERIFIED — ingress into the track and egress from the track were both "
   "measured, but no per-unit residence-then-exit counter was instrumented, so THROUGH_FLOW is not claimed; "
   "only FORCED_SOURCE_SINK_REPLACEMENT is."}
Path("forced_exchange_summary.json").write_text(json.dumps(summary,indent=1))
print("DECISION =",summary["DECISION"])

fig,axes=plt.subplots(2,3,figsize=(15.4,8.6)); fig.patch.set_facecolor(SURF)
for i,L in enumerate((24,32)):
    a0,a1,a2=axes[i]
    for ax in (a0,a1,a2):
        ax.set_facecolor(SURF); ax.grid(True,color=GRID,lw=0.8,axis="y",zorder=0)
        for sp in ("top","right"): ax.spines[sp].set_visible(False)
        for sp in ("left","bottom"): ax.spines[sp].set_color(GRID)
        ax.tick_params(colors=INK2,labelsize=9)
        ax.set_xticks([0,1]); ax.set_xticklabels(["Baseline","Law 16"],fontsize=9.5)
    w=0.26
    for k,iv in enumerate(IV):
        pos=[x+(k-1)*w for x in (0,1)]
        s15=[cells[f"{L}|{law}|{iv}"]["s1536"] for law in LAWS]
        s20=[cells[f"{L}|{law}|{iv}"]["s2048"] for law in LAWS]
        a0.bar(pos,s15,w*0.9,color=CI[iv],alpha=0.34,zorder=2,label=f"{iv} @1536" if i==0 else None)
        a0.bar(pos,s20,w*0.9,color=CI[iv],zorder=3,label=f"{iv} @2048 (coast)" if i==0 else None)
        for x,v in zip(pos,s20): a0.text(x,v+0.25,str(v),ha="center",color=INK,fontsize=8.5,fontweight="bold")
        rd=[cells[f"{L}|{law}|{iv}"]["resid_med"] or 0 for law in LAWS]
        fr=[cells[f"{L}|{law}|{iv}"]["fresh_med"] or 0 for law in LAWS]
        a1.bar(pos,rd,w*0.9,color=CI[iv],zorder=3)
        a1.plot(pos,fr,marker="D",ls="none",ms=8,color=INK,mec=SURF,mew=1.4,zorder=5,
                label="fraction source" if (i==0 and k==0) else None)
        ing=[cells[f"{L}|{law}|{iv}"]["ingress_med"] for law in LAWS]
        eg=[cells[f"{L}|{law}|{iv}"]["egress_med"] for law in LAWS]
        a2.bar([p-w*0.22 for p in pos],eg,w*0.42,color=CI[iv],zorder=3)
        a2.bar([p+w*0.22 for p in pos],ing,w*0.42,color=CI[iv],alpha=0.4,zorder=3,hatch="//",edgecolor=SURF)
    a0.set_ylim(0,14); a0.set_ylabel(f"L = {L}\n\nmondes survivants",color=INK2,fontsize=10)
    a1.axhline(0.20,color="#eb6834",lw=2.2,zorder=4); a1.set_ylim(0,1)
    a1.set_ylabel("résidu (barres) / fraction source (♦)",color=INK2,fontsize=10)
    a2.axhline(0.8*N0[L],color="#eb6834",lw=2.2,zorder=4)
    a2.set_ylabel("egress (plein) / ingress (hachuré), cellules",color=INK2,fontsize=10)
    a2.set_ylim(0,0.9*N0[L]*1.35)
axes[0][0].set_title("A · Survie : le forçage tue le disque",color=INK,fontsize=11.5,fontweight="bold",pad=8)
axes[0][1].set_title("B · Résidu et fraction source",color=INK,fontsize=11.5,fontweight="bold",pad=8)
axes[0][2].set_title("C · Échange délivré vs cible 0,80·N₀",color=INK,fontsize=11.5,fontweight="bold",pad=8)
axes[0][0].legend(frameon=False,fontsize=7.5,labelcolor=INK2,loc="upper right",ncol=1)
axes[0][1].legend(frameon=False,fontsize=8,labelcolor=INK2,loc="upper right")
axes[0][1].text(-0.42,0.235,"porte f = 0,20",color="#eb6834",fontsize=8.5,fontweight="bold")
axes[0][2].text(-0.42,0.8*202*1.04,"cible 0,80·N₀",color="#eb6834",fontsize=8.5,fontweight="bold")
fig.suptitle("Échange source–puits forcé sur disque unique — 0/144 succès conjoint",
             color=INK,fontsize=15,fontweight="bold",y=0.985)
fig.text(0.5,0.925,"144 trajectoires · 24 microétats t0 · balance événementielle exacte (erreur 0) · "
         "phase forcée 256→1536, coast 1536→2048",ha="center",color=INK2,fontsize=9.5)
fig.tight_layout(rect=[0,0,1,0.90]); fig.savefig("forced_exchange.png",dpi=170,facecolor=SURF)
print("figure -> forced_exchange.png")
