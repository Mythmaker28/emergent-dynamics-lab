"""ROUTE_E_DIRECT_INTERFACE_REPLACEMENT_FRONTIER_DEV_05 -- operator, provenance, ledgers.

Production engine, detector and advance_passive_tracer are used UNCHANGED (via od_core).
Nothing in edlab/ is modified.

DIFFERENCES FROM THE PARENT OPERATOR (declared: PARENT_OPERATOR_REPLICATION = REDESIGNED_PRESEAL
for the INSTRUMENTATION, with the PHYSICS held identical -- see direct_operator_nontriviality_audit):
  * the static per-cell `credited` counter is GONE. It is never computed, so it can never be
    re-read. All operator-introduced matter is permanently FRESH / DIRECT_OPERATOR_INSERTION.
  * the incumbent cohort is split at t256 into CORE / INTERMEDIATE / BOUNDARY by initial depth.
  * every event writes a ledger row; every checkpoint writes a lineage row.
  * atomicity is enforced and asserted, not merely expected.
"""
from __future__ import annotations
import math
from collections import deque
import numpy as np

from od_core import (THRESH, MMAX, comps, largest_bounded, cells_of, nbrs, fhash, advect,
                     LatticeBondState, LatticeBondEngine, graph_distance, AXES)

TOL = 1e-12
COHORTS = ("core", "inter", "bnd", "amb", "fre")
INCUMBENT = ("core", "inter", "bnd")


# ===================================================================== depth
def depth_partition(cells, L):
    """Depth of each C256 cell measured from OUTSIDE the component.
    BOUNDARY = depth 1, INTERMEDIATE = depth 2, CORE = depth >= 3. Frozen at t256."""
    inside = set(cells)
    d = {}
    q = deque()
    for i in inside:
        if any(n not in inside for n in nbrs(i, L)):
            d[i] = 1
            q.append(i)
    while q:
        i = q.popleft()
        for n in nbrs(i, L):
            if n in inside and n not in d:
                d[n] = d[i] + 1
                q.append(n)
    bnd = {i for i in inside if d.get(i, 99) == 1}
    inter = {i for i in inside if d.get(i, 99) == 2}
    core = {i for i in inside if d.get(i, 99) >= 3}
    return core, inter, bnd


# ================================================================ provenance
class Prov:
    """Five mutually exclusive material cohorts whose sum is identically the matter field.

    core/inter/bnd : INCUMBENT_256, split by initial depth inside C256 (sums to M256)
    amb            : AMBIENT_256, all matter outside C256 at t256
    fre            : FRESH_SOURCE, every unit introduced by the operator after t256

    Absorbing route: matter written into `fre` NEVER leaves `fre` while it is on the lattice.
    There is no credit field, no age field, and no per-cell counter of any kind.
    """

    __slots__ = ("f", "res_source", "res_sink", "sink_by_cohort", "M256")

    def __init__(self, state, cells256, L):
        core, inter, bnd = depth_partition(cells256, L)
        m = state.m
        self.f = {c: np.zeros_like(m) for c in COHORTS}
        flat = {c: self.f[c].reshape(-1) for c in COHORTS}
        fm = m.reshape(-1)
        inside = set(cells256)
        for i in range(m.size):
            if i in core:
                flat["core"][i] = fm[i]
            elif i in inter:
                flat["inter"][i] = fm[i]
            elif i in bnd:
                flat["bnd"][i] = fm[i]
            elif i not in inside:
                flat["amb"][i] = fm[i]
        self.res_source = 0.0
        self.res_sink = 0.0
        self.sink_by_cohort = {c: 0.0 for c in COHORTS}
        self.M256 = float(sum(fm[i] for i in cells256))

    # -- exact identity, checked after every mutation and every engine step --
    def identity_residual(self, state):
        s = self.f["core"] + self.f["inter"] + self.f["bnd"] + self.f["amb"] + self.f["fre"]
        return float(np.max(np.abs(state.m - s)))

    def global_balance_residual(self, state, total0):
        cur = float(state.m.sum()) + self.res_sink - self.res_source
        return abs(cur - total0)

    def advance(self, pre, ledger, post, dt):
        for c in COHORTS:
            self.f[c] = advect(self.f[c], pre, ledger, post, dt)

    def mass_in(self, cells, cohort):
        fl = self.f[cohort].reshape(-1)
        return float(sum(fl[i] for i in cells))

    def incumbent_in(self, cells):
        return sum(self.mass_in(cells, c) for c in INCUMBENT)


# =========================================================== site selection
# NOTE: every selector below reads ONLY the physical field `m`, the frozen mask and the
# current track. None of them reads any provenance field. This is asserted by the
# non-triviality audit through an AST scan, not by convention.

def select_sink_sites(fm, mask, track, L, quota):
    """Distributed partial removal: spread bites, avoid adjacent ones while others remain."""
    cands = [i for i in mask if i in track and fm[i] >= THRESH]
    chosen, used, b = [], set(), quota
    for strict in (True, False):
        for i in cands:
            if b <= TOL:
                break
            if i in used:
                continue
            if strict and any(n in used for n in nbrs(i, L)):
                continue
            chosen.append(i)
            used.add(i)
            b -= min(fm[i], b)
        if b <= TOL:
            break
    return chosen


def select_source_sites(fm, mask, track):
    return [i for i in mask if i in track and fm[i] < MMAX - TOL]


def sink_capacity(fm, mask, track):
    return float(sum(fm[i] for i in mask if i in track and fm[i] >= THRESH))


def source_capacity(fm, mask, track):
    return float(sum(MMAX - fm[i] for i in mask if i in track and fm[i] < MMAX - TOL))


# ================================================================ operations
def apply_sink(state, prov, sites, quota):
    """Removal is PROPORTIONAL to each cohort's local presence. The sink never selects
    matter by provenance; it takes a fraction of the cell and every cohort loses that same
    fraction."""
    fm = state.m.reshape(-1)
    fl = {c: prov.f[c].reshape(-1) for c in COHORTS}
    removed = 0.0
    out = {c: 0.0 for c in COHORTS}
    b = quota
    for i in sites:
        if b <= TOL:
            break
        take = min(fm[i], b)
        if take <= TOL:
            continue
        frac = take / fm[i]
        for c in COHORTS:
            d = fl[c][i] * frac
            fl[c][i] -= d
            out[c] += d
        fm[i] -= take
        removed += take
        b -= take
    prov.res_sink += removed
    for c in COHORTS:
        prov.sink_by_cohort[c] += out[c]
    return removed, out


def apply_source(state, prov, sites, quota):
    """Blank external payload: matter only. No state, no memory, no organisation field and
    no credit is copied from the target cell. `n` and `b` are untouched by the operator."""
    fm = state.m.reshape(-1)
    ff = prov.f["fre"].reshape(-1)
    injected = 0.0
    b = quota
    for i in sites:
        if b <= TOL:
            break
        cap = MMAX - fm[i]
        if cap <= TOL:
            continue
        add = min(b, cap)
        fm[i] += add
        ff[i] += add
        injected += add
        b -= add
    prov.res_source += injected
    return injected


# ====================================================== atomic direct event
def direct_event(state, prov, masks, track, L, planned, mode):
    """Both sides are SELECTED before either is MUTATED.

    mode DIRECT      : q = min(planned, sink_capacity, source_capacity); both sides move q,
                       or neither side moves at all.
    mode SINK_ONLY   : egress alone, deliberately un-coupled.
    mode SOURCE_ONLY : ingress alone, deliberately un-coupled.
    mode SHAM        : both selections are computed and thrown away; nothing is mutated.
    """
    fm = state.m.reshape(-1)
    m_before = state.m.copy()
    qs = sink_capacity(fm, masks["sink"], track)
    qi = source_capacity(fm, masks["source"], track)

    if mode == "SHAM":
        select_sink_sites(fm, masks["sink"], track, L, planned)
        select_source_sites(fm, masks["source"], track)
        return dict(q_event=0.0, realized_sink=0.0, realized_source=0.0,
                    removed_by_cohort={c: 0.0 for c in COHORTS},
                    physical_state_delta=0.0, n_sink_sites=0, n_source_sites=0,
                    atomic=True, rejected=True)

    if mode == "DIRECT":
        q = min(planned, qs, qi)
    elif mode == "SINK_ONLY":
        q = min(planned, qs)
    elif mode == "SOURCE_ONLY":
        q = min(planned, qi)
    else:
        raise ValueError(mode)

    if q <= TOL:
        return dict(q_event=0.0, realized_sink=0.0, realized_source=0.0,
                    removed_by_cohort={c: 0.0 for c in COHORTS},
                    physical_state_delta=0.0, n_sink_sites=0, n_source_sites=0,
                    atomic=True, rejected=True)

    sink_sites = select_sink_sites(fm, masks["sink"], track, L, q) if mode != "SOURCE_ONLY" else []
    src_sites = select_source_sites(fm, masks["source"], track) if mode != "SINK_ONLY" else []

    removed = 0.0
    by = {c: 0.0 for c in COHORTS}
    injected = 0.0
    if mode in ("DIRECT", "SINK_ONLY"):
        removed, by = apply_sink(state, prov, sink_sites, q)
    if mode == "DIRECT":
        # atomic: the source moves EXACTLY what the sink moved
        injected = apply_source(state, prov, src_sites, removed)
        if abs(injected - removed) > 1e-9:
            raise AssertionError(f"ATOMICITY_BROKEN removed={removed} injected={injected}")
    elif mode == "SOURCE_ONLY":
        injected = apply_source(state, prov, src_sites, q)

    delta = float(np.max(np.abs(state.m - m_before)))
    return dict(q_event=q, realized_sink=removed, realized_source=injected,
                removed_by_cohort=by, physical_state_delta=delta,
                n_sink_sites=len(sink_sites), n_source_sites=len(src_sites),
                atomic=(mode != "DIRECT") or abs(injected - removed) <= 1e-9,
                rejected=False)


# ==================================================================== masks
def build_masks_05(cells, L, cy, cx, axis):
    """Frozen at t256. sink = downstream half of C256; source interface = upstream half of
    C256. Both live INSIDE the component: this is the direct-interface geometry."""
    dy, dx = AXES[axis]
    yy, xx = np.mgrid[0:L, 0:L]
    proj = ((yy - cy) * dy + (xx - cx) * dx).reshape(-1)
    sink = sorted([i for i in cells if proj[i] > 0.0], key=lambda i: (-proj[i], i))
    source = sorted([i for i in cells if proj[i] < 0.0], key=lambda i: (proj[i], i))
    return {"sink": sink, "source": source, "axis": axis}


# ============================================================== observables
def scaffold(prov, cells, L):
    """Largest connected set of tracked cells whose INCUMBENT mass alone still clears the
    detector threshold. Frozen definition: a cell counts if core+inter+bnd >= THRESH."""
    fl = [prov.f[c].reshape(-1) for c in INCUMBENT]
    keep = {i for i in cells if (fl[0][i] + fl[1][i] + fl[2][i]) >= THRESH}
    if not keep:
        return 0, 0.0
    seen = set()
    best_n, best_m = 0, 0.0
    for s in keep:
        if s in seen:
            continue
        comp = []
        q = deque([s])
        seen.add(s)
        while q:
            i = q.popleft()
            comp.append(i)
            for n in nbrs(i, L):
                if n in keep and n not in seen:
                    seen.add(n)
                    q.append(n)
        mm = float(sum(fl[0][i] + fl[1][i] + fl[2][i] for i in comp))
        if len(comp) > best_n or (len(comp) == best_n and mm > best_m):
            best_n, best_m = len(comp), mm
    return best_n, best_m


def track_state(state):
    c = largest_bounded(state)
    if c is None:
        return None
    return c


class Lineage:
    """Frozen lineage classifier, evaluated at every measurement checkpoint.

    merger : the current track contains cells that belonged to a DIFFERENT component last time
    split  : last time's track cells are now spread over two or more distinct components
    loss   : no bounded non-wrapping component exists
    reacq  : a track exists again after a loss
    """

    __slots__ = ("prev_cells", "prev_label", "lost", "merger", "split", "reacq",
                 "first_failure_time", "first_failure_type", "continuous")

    def __init__(self):
        self.prev_cells = None
        self.prev_label = None
        self.lost = False
        self.merger = False
        self.split = False
        self.reacq = False
        self.first_failure_time = None
        self.first_failure_type = "NONE"
        self.continuous = True

    def _fail(self, t, kind):
        self.continuous = False
        if self.first_failure_time is None:
            self.first_failure_time = t
            self.first_failure_type = kind

    def update(self, state, t):
        allc = comps(state)
        label = {}
        for k, c in enumerate(allc):
            for i in cells_of(c):
                label[i] = k
        cur = track_state(state)
        if cur is None:
            if not self.lost:
                self._fail(t, "TRACK_LOST_OR_DISSOLVED")
            self.lost = True
            self.prev_cells, self.prev_label = None, label
            return None
        cells = cells_of(cur)
        if self.lost:
            self.reacq = True
            self._fail(t, "REACQUISITION")
        if cur.wraps_x or cur.wraps_y:
            self._fail(t, "WRAPPING")
        if self.prev_cells is not None and self.prev_label is not None:
            old = {self.prev_label[i] for i in cells if i in self.prev_label}
            if len(old) > 1:
                self.merger = True
                self._fail(t, "MERGER")
            now = {label[i] for i in self.prev_cells if i in label}
            if len(now) > 1:
                self.split = True
                self._fail(t, "SPLIT")
        self.prev_cells, self.prev_label = cells, label
        return cur


def snapshot(state, prov, L, M256, I0):
    """All endpoint quantities computed DIRECTLY, never by subtracting medians."""
    c = track_state(state)
    if c is None:
        return {"track": False}
    cells = cells_of(c)
    T = float(sum(state.m.reshape(-1)[i] for i in cells))
    I = prov.incumbent_in(cells)
    F = prov.mass_in(cells, "fre")
    A = prov.mass_in(cells, "amb")
    sn, sm = scaffold(prov, cells, L)
    out = {"track": True, "cells": cells, "area": c.area, "cy": c.centroid_y, "cx": c.centroid_x,
           "wrap": bool(c.wraps_x or c.wraps_y), "n_comp_total": None,
           "T": T, "I": I, "F": F, "A": A,
           "I_over_I0": (I / I0) if I0 > 0 else float("nan"),
           "I_over_T": (I / T) if T > 0 else float("nan"),
           "F_over_M256": F / M256, "F_over_T": (F / T) if T > 0 else float("nan"),
           "A_over_M256": A / M256, "A_over_T": (A / T) if T > 0 else float("nan"),
           "T_over_M256": T / M256,
           "scaffold_cells": sn, "scaffold_mass": sm,
           "scaffold_mass_over_I0": sm / I0 if I0 > 0 else float("nan")}
    for k in INCUMBENT:
        out[f"{k}_in_track"] = prov.mass_in(cells, k)
    return out
