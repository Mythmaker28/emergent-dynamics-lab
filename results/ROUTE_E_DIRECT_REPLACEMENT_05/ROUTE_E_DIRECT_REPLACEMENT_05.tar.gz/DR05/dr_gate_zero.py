"""GATE ZERO for DEV_05: is the direct operator a physical exchange or a relabeling?

No scientific engine is invoked. The operator is characterised by (a) an AST scan of its own
source and (b) numeric demonstrations on hand-built states.
"""
from __future__ import annotations
import ast, inspect, json
from pathlib import Path
import numpy as np

import dr_core as K
from dr_core import (Prov, direct_event, build_masks_05, apply_sink, apply_source,
                     select_sink_sites, select_source_sites, sink_capacity, source_capacity,
                     COHORTS, INCUMBENT, THRESH, MMAX, TOL)
from od_core import LatticeBondState, largest_bounded, cells_of

L = 24
FROZEN_TOL = 1e-9          # frozen non-triviality tolerance on the physical delta
PROV_NAMES = {"core", "inter", "bnd", "amb", "fre", "incumbent", "fresh", "ambient",
              "credited", "credit", "age", "component_id", "track_id"}


def state_from(m):
    return LatticeBondState(np.ascontiguousarray(m, dtype=np.float64),
                            np.full((L, L), 0.8), np.zeros((2, L, L)), 0)


def disc(cy, cx, r, val=0.9, bg=0.10):
    m = np.full((L, L), bg)
    yy, xx = np.mgrid[0:L, 0:L]
    m[((yy - cy) ** 2 + (xx - cx) ** 2) <= r * r] = val
    return m


def params_of(fn):
    return list(inspect.signature(fn).parameters)


def reads_provenance(fn):
    """A selector cannot read provenance if provenance is not in its signature AND its body
    references no cohort name."""
    src = inspect.getsource(fn)
    tree = ast.parse(src)
    names = {n.id for n in ast.walk(tree) if isinstance(n, ast.Name)} | \
            {n.attr for n in ast.walk(tree) if isinstance(n, ast.Attribute)}
    hit = sorted((names & PROV_NAMES))
    in_sig = [p for p in params_of(fn) if p in ("prov",)]
    return hit, in_sig


def main():
    audit = {"mission": "ROUTE_E_DIRECT_INTERFACE_REPLACEMENT_FRONTIER_DEV_05",
             "gate": "ZERO_PHYSICAL_EXCHANGE_OR_RELABEL",
             "scientific_engine_invocations": 0, "checks": []}

    def rec(name, ok, detail, **kw):
        audit["checks"].append({"check": name, "PASS": bool(ok), "detail": detail, **kw})
        print(f"  {name:<44} {'PASS' if ok else 'FAIL'}  {detail}")

    # ---------------- A. read / write sets, by construction -----------------
    sel = {}
    for fn in (select_sink_sites, select_source_sites, sink_capacity, source_capacity):
        hit, in_sig = reads_provenance(fn)
        sel[fn.__name__] = {"params": params_of(fn), "provenance_names_referenced": hit,
                            "takes_prov": in_sig}
    clean = all(len(v["provenance_names_referenced"]) == 0 and len(v["takes_prov"]) == 0
                for v in sel.values())
    audit["source_site_selection"] = {"function": "select_source_sites",
                                      "rule": "cells of the frozen upstream interface mask that are "
                                              "inside the current track and not saturated",
                                      "inputs": params_of(select_source_sites)}
    audit["sink_site_selection"] = {"function": "select_sink_sites",
                                    "rule": "cells of the frozen downstream mask inside the current "
                                            "track above threshold, spread to avoid adjacent bites",
                                    "inputs": params_of(select_sink_sites)}
    audit["operator_read_set"] = ["state.m", "frozen masks (built once at t256)", "current track cells",
                                  "planned quota"]
    audit["operator_write_set"] = ["state.m", "prov.f['fre'] (source)", "all five prov.f[*] "
                                   "proportionally (sink)", "prov.res_source", "prov.res_sink"]
    audit["active_state_fields"] = {"m": "written by the operator",
                                    "n": "NEVER touched by the operator",
                                    "b": "NEVER touched by the operator"}
    audit["memory_or_organization_fields"] = {"present_in_substrate": ["n", "b"],
                                              "written_by_operator": [],
                                              "note": "the external reservoir supplies bare matter only; "
                                                      "no state, memory, organisation or credit is copied "
                                                      "from the target cell"}
    audit["physical_payload"] = "+add to state.m at the target site"
    audit["provenance_payload"] = "+add to prov.f['fre'] at the same site, absorbing for life"
    audit["selectors"] = sel
    rec("selecteurs aveugles a la provenance", clean,
        "aucun selecteur ne prend `prov` en parametre ni ne nomme une cohorte -> "
        "la geometrie NE PEUT PAS lire INCUMBENT/FRESH/AMBIENT")

    # ---------------- B. the physical field really moves --------------------
    st = state_from(disc(12, 12, 5))
    c = largest_bounded(st)
    cells = cells_of(c)
    prov = Prov(st, cells, L)
    mk = build_masks_05(cells, L, c.centroid_y, c.centroid_x, "+x")
    m0 = st.m.copy()
    r = direct_event(st, prov, mk, cells, L, 1.0, "DIRECT")
    delta = float(np.max(np.abs(st.m - m0)))
    moved = float(np.abs(st.m - m0).sum())
    rec("delta d'etat PHYSIQUE hors provenance", delta > FROZEN_TOL,
        f"max|dm| = {delta:.6f} > {FROZEN_TOL:g} ; masse deplacee = {moved:.4f} ; "
        f"retire = {r['realized_sink']:.4f} injecte = {r['realized_source']:.4f}",
        physical_state_delta=delta, frozen_tolerance=FROZEN_TOL)

    # ---------------- C. relabeling alone cannot reproduce it ---------------
    st2 = state_from(disc(12, 12, 5))
    prov2 = Prov(st2, cells, L)
    fl = {cc: prov2.f[cc].reshape(-1) for cc in COHORTS}
    for i in cells:                       # relabel everything as FRESH, touch no physics
        tot = sum(fl[cc][i] for cc in COHORTS)
        for cc in COHORTS:
            fl[cc][i] = 0.0
        fl["fre"][i] = tot
    same_m = np.array_equal(st2.m, m0)
    rec("un pur reetiquetage ne reproduit PAS l'evenement", same_m and delta > FROZEN_TOL,
        "le reetiquetage laisse `m` bit-identique alors que l'evenement le modifie -> "
        "le resultat n'est pas atteignable en ne changeant que les etiquettes")

    # ---------------- D. atomicity -----------------------------------------
    st3 = state_from(disc(12, 12, 5))
    prov3 = Prov(st3, cells, L)
    r3 = direct_event(st3, prov3, mk, cells, L, 1.0, "DIRECT")
    rec("couple source-puits atomique", abs(r3["realized_source"] - r3["realized_sink"]) <= 1e-9,
        f"retire {r3['realized_sink']:.9f} == injecte {r3['realized_source']:.9f}")

    st4 = state_from(disc(12, 12, 5))
    prov4 = Prov(st4, cells, L)
    mk4 = dict(mk); mk4["source"] = []            # source impossible
    before = st4.m.copy()
    r4 = direct_event(st4, prov4, mk4, cells, L, 1.0, "DIRECT")
    rec("evenement entierement rejete si un cote est impossible",
        r4["rejected"] and np.array_equal(before, st4.m),
        "aucun des deux cotes n'est mute")

    # ---------------- E. proportional removal ------------------------------
    st5 = state_from(disc(12, 12, 5))
    prov5 = Prov(st5, cells, L)
    fl5 = {cc: prov5.f[cc].reshape(-1) for cc in COHORTS}
    i0 = mk["sink"][0]
    fl5["core"][i0] = st5.m.reshape(-1)[i0] * 0.4
    fl5["bnd"][i0] = st5.m.reshape(-1)[i0] * 0.6
    fl5["inter"][i0] = 0.0
    before_ratio = fl5["core"][i0] / fl5["bnd"][i0]
    rem, by = apply_sink(st5, prov5, [i0], st5.m.reshape(-1)[i0] * 0.5)
    after_ratio = fl5["core"][i0] / fl5["bnd"][i0]
    rec("retrait proportionnel a la presence locale",
        abs(before_ratio - after_ratio) < 1e-12 and abs(by["core"] / by["bnd"] - before_ratio) < 1e-12,
        f"rapport core/bnd inchange {before_ratio:.6f} -> {after_ratio:.6f} ; "
        f"le puits ne trie jamais par provenance")

    # ---------------- F. exact identity ------------------------------------
    st6 = state_from(disc(12, 12, 5))
    prov6 = Prov(st6, cells, L)
    tot0 = float(st6.m.sum())
    for _ in range(6):
        direct_event(st6, prov6, mk, cells, L, 0.7, "DIRECT")
    idr = prov6.identity_residual(st6)
    gbr = prov6.global_balance_residual(st6, tot0)
    rec("identite INCUMBENT+AMBIENT+FRESH = TOTAL", idr <= 1e-12 and gbr <= 1e-12,
        f"FLOAT_RECOMPUTATION_RESIDUAL identite = {idr:.2e}, bilan global = {gbr:.2e}",
        float_recomputation_residual=idr, global_balance_residual=gbr)

    # ---------------- G. no credit counter exists --------------------------
    tree = ast.parse(Path("dr_core.py").read_text())
    ids = {n.id for n in ast.walk(tree) if isinstance(n, ast.Name)} | \
          {n.attr for n in ast.walk(tree) if isinstance(n, ast.Attribute)} | \
          {s.value for n in ast.walk(tree) if isinstance(n, ast.Subscript)
           for s in ast.walk(n.slice) if isinstance(s, ast.Constant) and isinstance(s.value, str)}
    banned = sorted(ids & {"credited", "credit", "age", "shell_credit"})
    rec("aucun compteur `credited` / credit / age dans le CODE", len(banned) == 0,
        f"identifiants bannis references par le code: {banned if banned else 'aucun'} "
        "(la mention en docstring ne compte pas: elle n'est pas executable)")

    npass = sum(1 for c in audit["checks"] if c["PASS"])
    audit["OPERATOR_NONTRIVIALITY"] = "PASS" if npass == len(audit["checks"]) else "FAIL"
    audit["PARENT_OPERATOR_REPLICATION"] = "REDESIGNED_PRESEAL"
    audit["replication_note"] = (
        "The PHYSICS is the parent's: same interface geometry (downstream half of C256 as sink, "
        "upstream half as source), same per-event quantum, same schedule, same proportional "
        "removal, same bare-matter payload. The INSTRUMENTATION is redesigned: the static "
        "per-cell credit counter is removed, the incumbent cohort is split by depth, atomicity "
        "is asserted, and both ledgers are written. Declared REDESIGNED_PRESEAL, not EXACT.")
    Path("direct_operator_nontriviality_audit.json").write_text(json.dumps(audit, indent=1))
    print(f"\n{npass}/{len(audit['checks'])} -> OPERATOR_NONTRIVIALITY = {audit['OPERATOR_NONTRIVIALITY']}")
    return 0 if audit["OPERATOR_NONTRIVIALITY"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
