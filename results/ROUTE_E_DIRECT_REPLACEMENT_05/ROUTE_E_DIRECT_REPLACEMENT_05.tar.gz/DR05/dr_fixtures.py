"""DEV_05 fixtures. NO scientific engine is invoked: every state is hand-built and every
advection uses a SYNTHETIC gross-flow ledger constructed to satisfy the production
consistency relation post = pre - dt*div(net) exactly."""
from __future__ import annotations
import json, types
from pathlib import Path
import numpy as np

from dr_core import (Prov, Lineage, direct_event, build_masks_05, apply_sink, apply_source,
                     select_sink_sites, select_source_sites, depth_partition, scaffold,
                     snapshot, COHORTS, INCUMBENT, THRESH, MMAX, TOL)
from od_core import LatticeBondState, largest_bounded, cells_of, comps, advect, nbrs

L = 24
R = []


def check(n, name, ok, detail):
    R.append({"group": n, "name": name, "PASS": bool(ok), "detail": detail})
    print(f"  {n:>2}. {name:<50} {'PASS' if ok else 'FAIL'}  {detail}")


def state_from(m):
    return LatticeBondState(np.ascontiguousarray(m, dtype=np.float64),
                            np.full((L, L), 0.8), np.zeros((2, L, L)), 0)


def disc(cy, cx, r, val=0.9, bg=0.10):
    m = np.full((L, L), bg)
    yy, xx = np.mgrid[0:L, 0:L]
    m[((yy - cy) ** 2 + (xx - cx) ** 2) <= r * r] = val
    return m


def synthetic_flow(pre, dt=1.0, D=0.05):
    """Upwind diffusive gross flows and the exactly matching post field. No engine involved.
    One-sided gross flows keep the advected tracer inside [0, post], as the production
    tracer requires."""
    fwd = np.zeros((2, *pre.shape))
    rev = np.zeros((2, *pre.shape))
    for axis in (0, 1):
        nxt = np.roll(pre, -1, axis=axis)
        d = pre - nxt
        fwd[axis] = D * np.maximum(d, 0.0)
        rev[axis] = D * np.maximum(-d, 0.0)
    net = fwd - rev
    div = (net[0] - np.roll(net[0], 1, axis=0)) + (net[1] - np.roll(net[1], 1, axis=1))
    post = pre - dt * div
    assert post.min() >= 0.0, "synthetic diffusion went negative; lower D"
    led = types.SimpleNamespace(matter_forward=fwd, matter_reverse=rev, matter_scale=1.0)
    return led, post


# ---------------------------------------------- 1. exact t256 initialisation
def g1():
    st = state_from(disc(12, 12, 5))
    c = largest_bounded(st)
    cells = cells_of(c)
    p = Prov(st, cells, L)
    M256 = float(sum(st.m.reshape(-1)[i] for i in cells))
    inc = p.incumbent_in(cells)
    amb_in = p.mass_in(cells, "amb")
    fre_in = p.mass_in(cells, "fre")
    core, inter, bnd = depth_partition(cells, L)
    parts_ok = (len(core) + len(inter) + len(bnd) == len(cells)) and \
               (len(core & inter) == 0 and len(core & bnd) == 0 and len(inter & bnd) == 0)
    check(1, "incumbent_256 dans C256 == M256", abs(inc - M256) <= 1e-12,
          f"{inc:.9f} vs M256 {M256:.9f}")
    check(1, "ambient dans C256 == 0", amb_in == 0.0, f"{amb_in:.1e}")
    check(1, "fresh dans C256 == 0", fre_in == 0.0, f"{fre_in:.1e}")
    check(1, "I/I0 initial == 1 exactement", abs(inc / M256 - 1.0) <= 1e-15, "1.000000000000000")
    check(1, "partition CORE/INTERMEDIATE/BOUNDARY exclusive et complete", parts_ok,
          f"{len(core)} core + {len(inter)} inter + {len(bnd)} bnd = {len(cells)} cellules")
    check(1, "identite des cinq cohortes", p.identity_residual(st) <= 1e-15,
          f"residu = {p.identity_residual(st):.1e}")


# ------------------------------------------------------ 2. internal transfer
def g2():
    st = state_from(disc(12, 12, 5))
    c = largest_bounded(st); cells = cells_of(c)
    p = Prov(st, cells, L)
    fm = st.m.reshape(-1); fc = p.f["core"].reshape(-1)
    a, b = sorted(cells)[0], sorted(cells)[-1]
    q = min(fm[a], MMAX - fm[b]) * 0.5
    fa_before = fc[a]
    fm[a] -= q; fm[b] += q
    fc[a] -= q; fc[b] += q                      # a pure internal move of the SAME cohort
    inc_after = p.incumbent_in(cells)
    check(2, "transfert interne A->B: aucune masse fraiche creee",
          p.mass_in(cells, "fre") == 0.0 and abs(inc_after - p.M256) <= 1e-12,
          f"fresh = 0, incumbent inchange {inc_after:.9f}")
    check(2, "identite preservee apres transfert interne", p.identity_residual(st) <= 1e-12,
          f"residu = {p.identity_residual(st):.1e}")


# ---------------------------------------- 3. advection of every cohort
def g3():
    st = state_from(disc(12, 12, 5))
    c = largest_bounded(st); cells = cells_of(c)
    p = Prov(st, cells, L)
    mk = build_masks_05(cells, L, c.centroid_y, c.centroid_x, "+x")
    direct_event(st, p, mk, cells, L, 1.5, "DIRECT")     # give FRESH something to carry
    pre = st.m.copy()
    led, post = synthetic_flow(pre)
    tot_before = {k: float(p.f[k].sum()) for k in COHORTS}
    p.advance(pre, led, post, 1.0)
    st2 = state_from(post)
    tot_after = {k: float(p.f[k].sum()) for k in COHORTS}
    cons = max(abs(tot_after[k] - tot_before[k]) for k in COHORTS)
    resid = p.identity_residual(st2)
    # linearity: advecting the sum equals the sum of advected cohorts
    s_before = sum(np.zeros_like(pre) + 0 for _ in ())  # noqa
    summed = sum(p.f[k] for k in COHORTS)
    check(3, "chaque cohorte est conservee par l'advection", cons <= 1e-9,
          f"max |dmasse| sur les 5 cohortes = {cons:.2e}")
    check(3, "identite preservee apres advection (linearite)", resid <= 1e-9,
          f"FLOAT_RECOMPUTATION_RESIDUAL = {resid:.2e}")
    check(3, "aucune cohorte ne devient negative",
          min(float(p.f[k].min()) for k in COHORTS) >= -1e-12,
          f"min = {min(float(p.f[k].min()) for k in COHORTS):.2e}")


# ------------------------------------------------ 4. proportional sink
def g4():
    st = state_from(disc(12, 12, 5))
    c = largest_bounded(st); cells = cells_of(c)
    p = Prov(st, cells, L)
    fm = st.m.reshape(-1); fl = {k: p.f[k].reshape(-1) for k in COHORTS}
    i = sorted(cells)[3]
    tot = fm[i]
    fl["core"][i], fl["inter"][i], fl["bnd"][i] = tot * 0.5, tot * 0.3, tot * 0.2
    ratios = [fl[k][i] / tot for k in INCUMBENT]
    rem, by = apply_sink(st, p, [i], tot * 0.37)
    got = [by[k] / rem for k in INCUMBENT]
    ok = all(abs(a - b) <= 1e-12 for a, b in zip(ratios, got))
    check(4, "retrait strictement proportionnel aux cohortes locales", ok,
          f"parts retirees {['%.4f' % g for g in got]} == parts presentes {['%.4f' % r for r in ratios]}")
    check(4, "masse retiree == quota demande", abs(rem - tot * 0.37) <= 1e-12, f"{rem:.9f}")


# ------------------------------------------------- 5. blank external payload
def g5():
    st = state_from(disc(12, 12, 5))
    c = largest_bounded(st); cells = cells_of(c)
    p = Prov(st, cells, L)
    n0, b0 = st.n.copy(), st.b.copy()
    mk = build_masks_05(cells, L, c.centroid_y, c.centroid_x, "+x")
    sites = select_source_sites(st.m.reshape(-1), mk["source"], cells)
    inj = apply_source(st, p, sites, 0.8)
    fre_only = all(float(p.f[k].sum()) == (p.M256 if k in INCUMBENT else 0.0) or k == "fre"
                   for k in COHORTS)
    check(5, "payload exterieur = matiere nue, `n` et `b` intacts",
          np.array_equal(n0, st.n) and np.array_equal(b0, st.b),
          "aucun champ de memoire ou d'organisation n'est ecrit par l'operateur")
    check(5, "toute la matiere introduite est FRESH", abs(float(p.f["fre"].sum()) - inj) <= 1e-12,
          f"injecte {inj:.6f} == fresh total {float(p.f['fre'].sum()):.6f}")
    check(5, "reservoir source debite du meme montant", abs(p.res_source - inj) <= 1e-12,
          f"res_source = {p.res_source:.6f}")


# ------------------------------------- 6. partially realisable coupled event
def g6():
    st = state_from(disc(12, 12, 5))
    c = largest_bounded(st); cells = cells_of(c)
    p = Prov(st, cells, L)
    mk = build_masks_05(cells, L, c.centroid_y, c.centroid_x, "+x")
    huge = 1e6
    r = direct_event(st, p, mk, cells, L, huge, "DIRECT")
    check(6, "quota reduit identiquement des deux cotes",
          abs(r["realized_source"] - r["realized_sink"]) <= 1e-9 and r["q_event"] < huge,
          f"q reduit a {r['q_event']:.4f}, retire {r['realized_sink']:.4f} == injecte {r['realized_source']:.4f}")
    st2 = state_from(disc(12, 12, 5))
    p2 = Prov(st2, cells, L)
    mk2 = dict(mk); mk2["source"] = []
    before = st2.m.copy()
    r2 = direct_event(st2, p2, mk2, cells, L, 1.0, "DIRECT")
    check(6, "sinon evenement entier rejete, aucun cote mute",
          r2["rejected"] and np.array_equal(before, st2.m), "etat bit-identique")


# ------------------------------------------------- 7. pure relabeling refused
def g7():
    st = state_from(disc(12, 12, 5))
    c = largest_bounded(st); cells = cells_of(c)
    p = Prov(st, cells, L)
    m0 = st.m.copy()
    fl = {k: p.f[k].reshape(-1) for k in COHORTS}
    for i in cells:                       # relabel incumbent as fresh, touch no physics
        t = sum(fl[k][i] for k in COHORTS)
        for k in COHORTS:
            fl[k][i] = 0.0
        fl["fre"][i] = t
    delta = float(np.max(np.abs(st.m - m0)))
    check(7, "le reetiquetage ne produit AUCUN delta physique", delta == 0.0,
          f"max|dm| = {delta:.1e} -> un tel evenement ne passerait pas la porte zero")
    st2 = state_from(disc(12, 12, 5))
    p2 = Prov(st2, cells, L)
    mk = build_masks_05(cells, L, c.centroid_y, c.centroid_x, "+x")
    r = direct_event(st2, p2, mk, cells, L, 1.0, "DIRECT")
    check(7, "l'operateur reel produit un delta physique > tolerance",
          r["physical_state_delta"] > 1e-9, f"delta = {r['physical_state_delta']:.6f}")


# --------------------------------------- 8. operator never reads provenance
def g8():
    st = state_from(disc(12, 12, 5))
    c = largest_bounded(st); cells = cells_of(c)
    mk = build_masks_05(cells, L, c.centroid_y, c.centroid_x, "+x")
    pA = Prov(st, cells, L)
    stB = state_from(st.m.copy())
    pB = Prov(stB, cells, L)
    fl = {k: pB.f[k].reshape(-1) for k in COHORTS}      # completely different labelling
    for i in cells:
        t = sum(fl[k][i] for k in COHORTS)
        for k in COHORTS:
            fl[k][i] = 0.0
        fl["fre"][i] = t
    fmA, fmB = st.m.reshape(-1), stB.m.reshape(-1)
    sA = select_sink_sites(fmA, mk["sink"], cells, L, 1.0)
    sB = select_sink_sites(fmB, mk["sink"], cells, L, 1.0)
    uA = select_source_sites(fmA, mk["source"], cells)
    uB = select_source_sites(fmB, mk["source"], cells)
    check(8, "selection identique sous un etiquetage totalement different",
          sA == sB and uA == uB,
          f"{len(sA)} sites puits et {len(uA)} sites source, identiques dans les deux mondes")


# ------------------------------- 9. split, merger, loss, reacquisition
def g9():
    lin = Lineage()
    lin.update(state_from(disc(12, 12, 4)), 0)
    m = disc(8, 8, 3); yy, xx = np.mgrid[0:L, 0:L]
    m[((yy - 17) ** 2 + (xx - 17) ** 2) <= 4] = 0.9
    lin2 = Lineage()
    big = disc(12, 12, 4)
    lin2.update(state_from(big), 0)
    split_state = np.full((L, L), 0.10)
    split_state[9:12, 9:12] = 0.9
    split_state[14:17, 14:17] = 0.9
    lin2.update(state_from(split_state), 16)
    check(9, "scission detectee", lin2.split is True or lin2.first_failure_type in ("SPLIT", "MERGER"),
          f"type={lin2.first_failure_type} split={lin2.split}")
    lin3 = Lineage()
    two = np.full((L, L), 0.10); two[9:13, 5:9] = 0.9; two[9:13, 14:18] = 0.9
    lin3.update(state_from(two), 0)
    merged = np.full((L, L), 0.10); merged[9:13, 5:18] = 0.9
    lin3.update(state_from(merged), 16)
    check(9, "fusion detectee", lin3.merger is True, f"merger={lin3.merger}")
    lin4 = Lineage()
    lin4.update(state_from(disc(12, 12, 4)), 0)
    lin4.update(state_from(np.full((L, L), 0.10)), 16)
    check(9, "perte de piste detectee", lin4.lost is True and lin4.first_failure_type ==
          "TRACK_LOST_OR_DISSOLVED", f"type={lin4.first_failure_type}")
    lin4.update(state_from(disc(12, 12, 4)), 32)
    check(9, "reacquisition detectee et marquee comme echec", lin4.reacq is True,
          f"reacq={lin4.reacq}, premier echec reste a t={lin4.first_failure_time}")


# ----------------------------------------- 10. cell-by-cell recomposition
def g10():
    st = state_from(disc(12, 12, 5))
    c = largest_bounded(st); cells = cells_of(c)
    p = Prov(st, cells, L)
    mk = build_masks_05(cells, L, c.centroid_y, c.centroid_x, "+x")
    for _ in range(4):
        direct_event(st, p, mk, cells, L, 0.9, "DIRECT")
    fm = st.m.reshape(-1)
    fl = {k: p.f[k].reshape(-1) for k in COHORTS}
    worst = 0.0
    for i in range(L * L):
        s = sum(fl[k][i] for k in COHORTS)
        worst = max(worst, abs(s - fm[i]))
    snap = snapshot(st, p, L, p.M256, p.M256)
    parts = snap["I"] + snap["F"] + snap["A"]
    check(10, "recomposition exacte cellule par cellule", worst <= 1e-12,
          f"pire ecart sur {L*L} cellules = {worst:.2e}")
    check(10, "recomposition exacte au niveau de la piste", abs(parts - snap["T"]) <= 1e-12,
          f"I+F+A = {parts:.9f} vs T = {snap['T']:.9f}")
    check(10, "echafaudage incumbent calculable", snap["scaffold_cells"] > 0,
          f"{snap['scaffold_cells']} cellules, masse {snap['scaffold_mass']:.3f}")


def main():
    print("=== FIXTURES DEV_05 (aucun appel au moteur scientifique) ===")
    for f in (g1, g2, g3, g4, g5, g6, g7, g8, g9, g10):
        try:
            f()
        except Exception as e:
            check(int(f.__name__[1:]), f.__name__, False, f"EXCEPTION {type(e).__name__}: {e}")
    n = sum(1 for r in R if r["PASS"])
    prov_ok = all(r["PASS"] for r in R if r["group"] in (1, 2, 3, 4, 5, 10))
    lin_ok = all(r["PASS"] for r in R if r["group"] == 9)
    verdict = "PASS" if n == len(R) else "FAIL"
    Path("direct_operator_fixtures.json").write_text(json.dumps(
        {"mission": "ROUTE_E_DIRECT_INTERFACE_REPLACEMENT_FRONTIER_DEV_05",
         "engine_invocations": 0, "n": len(R), "n_pass": n,
         "PROVENANCE_FIXTURES": "PASS" if prov_ok else "FAIL",
         "LINEAGE_FIXTURES": "PASS" if lin_ok else "FAIL",
         "OPERATOR_FIXTURES": verdict, "fixtures": R}, indent=1))
    print(f"\n{n}/{len(R)} -> {verdict}   (provenance {'PASS' if prov_ok else 'FAIL'}, "
          f"lineage {'PASS' if lin_ok else 'FAIL'})")
    return 0 if verdict == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
