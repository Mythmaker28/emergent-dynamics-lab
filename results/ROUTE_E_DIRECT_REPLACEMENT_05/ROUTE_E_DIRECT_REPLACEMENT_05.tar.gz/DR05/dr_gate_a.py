"""Stage A gate for DEV_05. Pre-sealed rules only, explicit comparisons only, no engine."""
from __future__ import annotations
import csv, json, math
from pathlib import Path

TOLR = 1e-9


def num(v):
    if v is None or v in ("", "None", "nan", "NaN"):
        return None
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return None if math.isnan(x) else x


def boolean(v):
    return v == "True" or v is True


def main():
    rows = list(csv.DictReader(open("direct_replacement_rows_a.csv")))
    man = json.loads(Path("t256_checkpoint_manifest.json").read_text())
    gz = json.loads(Path("direct_operator_nontriviality_audit.json").read_text())
    blocks = [b for b in man["blocks"]]
    valid = [b for b in blocks if b["t256_status"] == "T256_VALID_TRACK"]
    init_ok = sum(1 for b in valid if b.get("t256_initialisation_exact") is True)
    by_size = {}
    for L in (24, 32):
        by_size[str(L)] = {"T256_VALID": sum(1 for b in valid if b["size"] == L),
                           "n_blocks": sum(1 for b in blocks if b["size"] == L)}

    anchor = [r for r in rows if r["arm"] == "DIRECT_Q100_ANCHOR"]
    sham = {(r["size"], r["block"]): r for r in rows if r["arm"] == "SHAM"}

    inv_ok = 0
    per = []
    for r in rows:
        idr = num(r.get("max_identity_residual"))
        gbr = num(r.get("max_global_balance_residual"))
        if idr is not None and gbr is not None and idr <= TOLR and gbr <= TOLR:
            inv_ok += 1
    for r in anchor:
        M = num(r["M256"])
        I0 = num(r["I0"])
        F_t = num(r.get("terminal_F"))
        F_f = num(r.get("force_end_F"))
        I_t = num(r.get("terminal_I"))
        Tr = num(r.get("terminal_T_over_M256"))
        c = {
            "same_track_continuous": boolean(r["same_track_continuous"]),
            "never_merged": boolean(r["merger"]) is False,
            "never_split": boolean(r["split"]) is False,
            "no_reacquisition": boolean(r["reacquisition"]) is False,
            "frozen_mass_gate": (Tr is not None and 0.75 <= Tr <= 1.25),
            "frozen_coast_gate": (F_t is not None and F_f is not None and F_f > 0
                                  and (F_t / F_f) >= 0.50),
            "fresh_over_M256_ge_015": (F_t is not None and M is not None and (F_t / M) >= 0.15),
            "incumbent_loss_ge_020": (I_t is not None and I0 is not None and I0 > 0
                                      and (1.0 - I_t / I0) >= 0.20),
        }
        per.append({"block": r["block"], "size": int(r["size"]),
                    "F_over_M256": (F_t / M) if (F_t is not None and M) else None,
                    "incumbent_loss": (1.0 - I_t / I0) if (I_t is not None and I0) else None,
                    "coast_ratio": (F_t / F_f) if (F_t is not None and F_f) else None,
                    "T_over_M256": Tr, "ALL": all(c.values()), **c})

    size_pass = {}
    for L in (24, 32):
        g = [p for p in per if p["size"] == L]
        size_pass[str(L)] = {"n": len(g), "pass": sum(1 for p in g if p["ALL"] is True),
                             "required": 7}
        for k in ("same_track_continuous", "never_merged", "never_split", "no_reacquisition",
                  "frozen_mass_gate", "frozen_coast_gate", "fresh_over_M256_ge_015",
                  "incumbent_loss_ge_020"):
            size_pass[str(L)][k] = sum(1 for p in g if p[k] is True)

    global_ok = (inv_ok == len(rows) and gz["OPERATOR_NONTRIVIALITY"] == "PASS"
                 and init_ok == len(valid) and len(valid) == 18)
    per_size_ok = all(size_pass[str(L)]["pass"] >= 7 for L in (24, 32))
    gate = "PASS" if (global_ok and per_size_ok) else "FAIL"
    out = {"mission": "ROUTE_E_DIRECT_INTERFACE_REPLACEMENT_FRONTIER_DEV_05",
           "STAGE_A_GATE": gate,
           "PROVENANCE_AND_LEDGER_INVARIANTS": f"{inv_ok}/{len(rows)}",
           "OPERATOR_NONTRIVIALITY": gz["OPERATOR_NONTRIVIALITY"],
           "T256_INITIALIZATION": f"{init_ok}/{len(valid)}",
           "T256_VALID_BY_SIZE": by_size, "per_size": size_pass, "per_block": per,
           "decision_if_fail": "DIRECT_Q100_SIGNAL_NOT_REPLICATED"}
    Path("stage_a_gate.json").write_text(json.dumps(out, indent=1))
    print("STAGE_A_GATE =", gate)
    print(" invariants:", out["PROVENANCE_AND_LEDGER_INVARIANTS"],
          "| t256 init:", out["T256_INITIALIZATION"], "| valides:", by_size)
    for L in (24, 32):
        s = size_pass[str(L)]
        print(f" L={L}: {s['pass']}/{s['n']} blocs passent les 8 criteres (requis 7)")
        print("   ", {k: v for k, v in s.items() if k not in ("n", "pass", "required")})


if __name__ == "__main__":
    main()
