"""DEV_05 analysis, endpoints and figure. Pre-sealed rules, explicit comparisons, no engine."""
from __future__ import annotations
import csv, json, math, statistics as st
from pathlib import Path
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

TOLR = 1e-9
SIZES = (24, 32)
DOSE = {"DIRECT_Q100_ANCHOR": 1, "DIRECT_Q200_UNIFORM": 2, "DIRECT_Q400_UNIFORM": 4,
        "DIRECT_Q800_UNIFORM": 8}
LADDER = list(DOSE)
INK, INK2, GRID, SURF = "#0b0b0b", "#52514e", "#d8d7d2", "#fcfcfb"
C = {"I": "#8c8b86", "F": "#1baf7a", "A": "#eda100", "T": "#2a78d6", "S": "#eb6834",
     "B": "#4a3aa7", "R": "#b02020"}


def num(v):
    if v is None or v in ("", "None", "nan", "NaN"):
        return None
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return None if math.isnan(x) else x


def boolean(v):
    return v == "True" or v is True


rows = []
for f in ("direct_replacement_rows_a.csv", "direct_replacement_rows_b.csv"):
    if Path(f).exists():
        rows += list(csv.DictReader(open(f)))
for r in rows:
    r["size"] = int(r["size"])
sham = {(r["size"], r["block"]): r for r in rows if r["arm"] == "SHAM"}
SNAP = {(r["size"], r["block"], r["arm"]): json.loads(r["snapshots"]) for r in rows}
ARMS = [a for a in ("SHAM", "DIRECT_Q100_ANCHOR", "DIRECT_Q200_UNIFORM", "DIRECT_Q400_UNIFORM",
                    "DIRECT_Q800_UNIFORM", "DIRECT_Q400_BURST", "SINK_ONLY_Q800",
                    "SOURCE_ONLY_Q800") if any(r["arm"] == a for r in rows)]


def sham_I_at(size, block, t):
    s = SNAP.get((size, block, "SHAM"), {})
    e = s.get(str(int(t)))
    if e is None or not e.get("track"):
        return None
    return e.get("I")


def endpoints(r):
    """Frozen endpoints. A and B are NEVER conflated."""
    M, I0 = num(r["M256"]), num(r["I0"])
    I, T, F, A = (num(r.get(f"terminal_{k}")) for k in ("I", "T", "F", "A"))
    Ff = num(r.get("force_end_F"))
    Tr = num(r.get("terminal_T_over_M256"))
    idr, gbr = num(r.get("max_identity_residual")), num(r.get("max_global_balance_residual"))
    ledger = (idr is not None and gbr is not None and idr <= TOLR and gbr <= TOLR)
    lineage = (boolean(r["same_track_continuous"]) and boolean(r["merger"]) is False
               and boolean(r["split"]) is False and boolean(r["reacquisition"]) is False)
    mass_gate = (Tr is not None and 0.75 <= Tr <= 1.25)
    coast_gate = (F is not None and Ff is not None and Ff > 0 and (F / Ff) >= 0.50)
    if r["arm"] == "SHAM":
        coast_gate = True
    Isham = sham_I_at(r["size"], r["block"], num(r["terminal_time"]))
    excess = (max(0.0, Isham - I) / M) if (Isham is not None and I is not None and M) else None
    mfr = (min(excess, F / M) if (excess is not None and F is not None and M) else None)
    tv = (I is not None and I0 and (I / I0) <= 0.20)
    tv2 = (I is not None and T and (I / T) <= 0.20)
    turnover = bool(tv and tv2 and mass_gate and coast_gate and lineage and ledger)
    src = bool(turnover and T and F is not None and (F / T) >= 0.80
               and M and (F / M) >= 0.80 and mfr is not None and mfr >= 0.80)
    return {"I_over_I0": (I / I0) if (I is not None and I0) else None,
            "I_over_T": (I / T) if (I is not None and T) else None,
            "F_over_M256": (F / M) if (F is not None and M) else None,
            "F_over_T": (F / T) if (F is not None and T) else None,
            "A_over_M256": (A / M) if (A is not None and M) else None,
            "A_over_T": (A / T) if (A is not None and T) else None,
            "T_over_M256": Tr, "sham_I_matched": Isham,
            "EXCESS_INCUMBENT_EGRESS": excess, "MATCHED_FRESH_REPLACEMENT": mfr,
            "mass_gate": mass_gate, "coast_gate": coast_gate, "lineage_ok": lineage,
            "ledger_ok": ledger,
            "FORCED_COMPONENT_TURNOVER_80": turnover,
            "DIRECT_SOURCE_REPLACEMENT_80": src,
            "scaffold_cells": num(r.get("terminal_scaffold_cells")),
            "scaffold_mass_over_I0": num(r.get("terminal_scaffold_mass_over_I0")),
            "core_over_I0": ((num(r.get("terminal_core_in_track")) / I0)
                             if (num(r.get("terminal_core_in_track")) is not None and I0) else None)}


aud = []
for r in rows:
    e = endpoints(r)
    aud.append({"block": r["block"], "size": r["size"], "arm": r["arm"],
                "terminal_time": num(r["terminal_time"]),
                "realized_source": num(r["realized_source"]),
                "realized_sink": num(r["realized_sink"]),
                "planned_source": num(r["planned_source"]),
                "planned_sink": num(r["planned_sink"]),
                "merger": boolean(r["merger"]), "split": boolean(r["split"]),
                "loss": boolean(r["loss"]), "reacquisition": boolean(r["reacquisition"]),
                "first_failure_type": r["first_failure_type"],
                "first_failure_time": r["first_failure_time"],
                "first_cross_turnover": r["first_cross_turnover"],
                "first_cross_source": r["first_cross_source"], **e})
f = sorted({k for a in aud for k in a})
with Path("direct_replacement_endpoint_audit.csv").open("w", newline="") as h:
    w = csv.DictWriter(h, fieldnames=f); w.writeheader(); w.writerows(aud)


def cell(size, arm):
    return [a for a in aud if a["size"] == size and a["arm"] == arm]


def stat(g, k):
    v = [x[k] for x in g if x.get(k) is not None]
    if not v:
        return None, None, None, []
    return min(v), st.median(v), max(v), v


summary = {"mission": "ROUTE_E_DIRECT_INTERFACE_REPLACEMENT_FRONTIER_DEV_05",
           "protocol_sha256": json.loads(Path("t256_checkpoint_manifest.json").read_text())["protocol_sha256"],
           "logical_trajectories": len(rows), "arms": ARMS, "by_size": {}}
for L in SIZES:
    cs = {}
    for a in ARMS:
        g = cell(L, a)
        if not g:
            continue
        d = {"n": len(g)}
        for k in ("realized_source", "realized_sink", "I_over_I0", "I_over_T", "F_over_M256",
                  "F_over_T", "A_over_M256", "A_over_T", "T_over_M256",
                  "MATCHED_FRESH_REPLACEMENT", "EXCESS_INCUMBENT_EGRESS",
                  "scaffold_cells", "scaffold_mass_over_I0", "core_over_I0"):
            lo, me, hi, v = stat(g, k)
            d[k] = {"min": lo, "median": me, "max": hi, "values": v}
        d["merger"] = sum(1 for x in g if x["merger"])
        d["split"] = sum(1 for x in g if x["split"])
        d["loss"] = sum(1 for x in g if x["loss"])
        d["reacquisition"] = sum(1 for x in g if x["reacquisition"])
        d["lineage_ok"] = sum(1 for x in g if x["lineage_ok"])
        d["mass_gate"] = sum(1 for x in g if x["mass_gate"])
        d["coast_gate"] = sum(1 for x in g if x["coast_gate"])
        d["ledger_ok"] = sum(1 for x in g if x["ledger_ok"])
        d["turnover80"] = sum(1 for x in g if x["FORCED_COMPONENT_TURNOVER_80"])
        d["source_replacement80"] = sum(1 for x in g if x["DIRECT_SOURCE_REPLACEMENT_80"])
        d["risk_set_intact"] = sum(1 for x in g if x["lineage_ok"])
        d["first_failure_types"] = sorted({x["first_failure_type"] for x in g})
        cs[a] = d
    summary["by_size"][str(L)] = cs

# paired uniform vs burst at Q400
rate = {}
for L in SIZES:
    u = {x["block"]: x for x in cell(L, "DIRECT_Q400_UNIFORM")}
    b = {x["block"]: x for x in cell(L, "DIRECT_Q400_BURST")}
    keys = [k for k in u if k in b]
    d = [(b[k]["I_over_I0"] - u[k]["I_over_I0"]) for k in keys
         if u[k]["I_over_I0"] is not None and b[k]["I_over_I0"] is not None]
    df = [(b[k]["F_over_T"] - u[k]["F_over_T"]) for k in keys
          if u[k]["F_over_T"] is not None and b[k]["F_over_T"] is not None]
    rate[str(L)] = {"n_pairs": len(d),
                    "median_delta_I_over_I0_burst_minus_uniform": (st.median(d) if d else None),
                    "median_delta_F_over_T_burst_minus_uniform": (st.median(df) if df else None),
                    "n_burst_lower_I": sum(1 for x in d if x < 0),
                    "n_burst_higher_I": sum(1 for x in d if x > 0)}
summary["rate_effect_Q400_burst_vs_uniform"] = rate


def collective(name, key):
    out = {}
    for L in SIZES:
        best = None
        for a in ARMS:
            c = summary["by_size"][str(L)].get(a)
            if c is None or a == "SHAM":
                continue
            if best is None or c[key] > best[1]:
                best = (a, c[key])
        out[str(L)] = {"best_arm": best[0] if best else None,
                       "n_pass": best[1] if best else 0, "required": 7}
    met = all(out[str(L)]["n_pass"] >= 7 for L in SIZES)
    summary[name] = {"per_size": out, "MET": met}
    return met


turn_met = collective("FORCED_COMPONENT_TURNOVER_80_COLLECTIVE", "turnover80")
src_met = collective("DIRECT_SOURCE_REPLACEMENT_80_COLLECTIVE", "source_replacement80")

# breakage frontier: paired, a lower dose passes and a higher one fails
frontier = {}
for L in SIZES:
    lad = [(a, summary["by_size"][str(L)][a]["lineage_ok"]) for a in LADDER
           if a in summary["by_size"][str(L)]]
    frontier[str(L)] = {"lineage_intact_by_dose": lad,
                        "turnover_by_dose": [(a, summary["by_size"][str(L)][a]["turnover80"])
                                             for a in LADDER if a in summary["by_size"][str(L)]]}
summary["frontier"] = frontier
summary["ORGANIZATION_PRESERVATION"] = "NOT_TESTED"
summary["claim_ceiling"] = "TRACKED_COMPONENT_CONTINUITY_UNDER_FORCED_TURNOVER"


def decide():
    if any(summary["by_size"][str(L)].get("DIRECT_Q100_ANCHOR", {}).get("ledger_ok", 0) < 9
           for L in SIZES):
        return "INVALID_OPERATOR_OR_PROVENANCE"
    if src_met:
        return "DIRECT_SOURCE_REPLACEMENT_80_DEV"
    if turn_met:
        scaf = [summary["by_size"][str(L)]["DIRECT_Q800_UNIFORM"]["scaffold_cells"]["median"]
                for L in SIZES if "DIRECT_Q800_UNIFORM" in summary["by_size"][str(L)]]
        if any(s is not None and s > 0 for s in scaf):
            return "BULK_TURNOVER_WITH_PERSISTENT_INCUMBENT_SCAFFOLD"
        return "TRACKED_COMPONENT_TURNOVER_80_DEV"
    top = [summary["by_size"][str(L)].get("DIRECT_Q800_UNIFORM", {}).get("I_over_I0", {}).get("median")
           for L in SIZES]
    if all(x is not None and x > 0.20 for x in top):
        return "DOSE_RANGE_INSUFFICIENT"
    return "COMPONENT_CONTINUITY_ONLY"


summary["DECISION"] = decide()
Path("direct_replacement_summary.json").write_text(json.dumps(summary, indent=1))
print("DECISION =", summary["DECISION"])
for L in SIZES:
    for a in ARMS:
        c = summary["by_size"][str(L)].get(a)
        if not c:
            continue
        print(f"  L={L} {a:<22} I/I0 {c['I_over_I0']['median']} F/T {c['F_over_T']['median']} "
              f"turn {c['turnover80']}/{c['n']} src {c['source_replacement80']}/{c['n']} "
              f"lineage {c['lineage_ok']}/{c['n']}")

# ==================================================================== figure
fig, axes = plt.subplots(2, 3, figsize=(15.8, 8.8))
fig.patch.set_facecolor(SURF)
for i, L in enumerate(SIZES):
    a0, a1, a2 = axes[i]
    for ax in (a0, a1, a2):
        ax.set_facecolor(SURF); ax.grid(True, color=GRID, lw=0.8, axis="y", zorder=0)
        for sp in ("top", "right"): ax.spines[sp].set_visible(False)
        for sp in ("left", "bottom"): ax.spines[sp].set_color(GRID)
        ax.tick_params(colors=INK2, labelsize=9)
    S = summary["by_size"][str(L)]
    lad = [a for a in LADDER if a in S]
    xs = [DOSE[a] for a in lad]

    # col 1: composition vs dose, per block + median
    for key, col, lab in (("I_over_T", C["I"], "I/T incumbent"),
                          ("F_over_T", C["F"], "F/T source fraîche"),
                          ("A_over_T", C["A"], "A/T ambiant")):
        blocks = sorted({x["block"] for x in aud if x["size"] == L})
        for b in blocks:
            ys = []
            for a in lad:
                m = [x for x in aud if x["size"] == L and x["arm"] == a and x["block"] == b]
                ys.append(m[0][key] if m and m[0][key] is not None else float("nan"))
            a0.plot(xs, ys, "-", color=col, lw=0.7, alpha=0.30, zorder=2)
        med = [S[a][key]["median"] if S[a][key]["median"] is not None else float("nan") for a in lad]
        a0.plot(xs, med, "o-", color=col, lw=2.6, ms=7, zorder=4, label=lab if i == 0 else None)
    a0.axhline(0.20, color=C["R"], lw=1.4, ls="--", zorder=3)
    a0.axhline(0.80, color=C["R"], lw=1.4, zorder=3)
    a0.set_xscale("log", base=2); a0.set_xticks(xs)
    a0.set_xticklabels([f"Q{d*100}" for d in xs], fontsize=9)
    a0.set_ylim(-0.03, 1.03)
    a0.set_ylabel(f"L = {L}\n\nfraction de la piste", color=INK2, fontsize=10)

    # col 2: I/I0 and T/M256 vs dose, sham reference
    for key, col, mk, lab in (("I_over_I0", C["I"], "o", "I/I₀ cohorte initiale"),
                              ("T_over_M256", C["T"], "s", "T/M₂₅₆ masse suivie"),
                              ("MATCHED_FRESH_REPLACEMENT", C["F"], "^", "remplacement apparié")):
        med = [S[a][key]["median"] if S[a][key]["median"] is not None else float("nan") for a in lad]
        lo = [S[a][key]["min"] if S[a][key]["min"] is not None else float("nan") for a in lad]
        hi = [S[a][key]["max"] if S[a][key]["max"] is not None else float("nan") for a in lad]
        a1.fill_between(xs, lo, hi, color=col, alpha=0.16, zorder=2)
        a1.plot(xs, med, mk + "-", color=col, lw=2.4, ms=7, zorder=4, label=lab if i == 0 else None)
    if "SHAM" in S and S["SHAM"]["I_over_I0"]["median"] is not None:
        a1.axhline(S["SHAM"]["I_over_I0"]["median"], color=C["S"], lw=1.6, ls=":", zorder=3,
                   label="I/I₀ du SHAM" if i == 0 else None)
    a1.axhline(0.20, color=C["R"], lw=1.4, ls="--", zorder=3)
    a1.axhline(0.80, color=C["R"], lw=1.4, zorder=3)
    a1.set_xscale("log", base=2); a1.set_xticks(xs)
    a1.set_xticklabels([f"Q{d*100}" for d in xs], fontsize=9)
    a1.set_ylim(-0.03, 1.28)
    a1.set_ylabel("fraction de M₂₅₆ / I₀", color=INK2, fontsize=10)

    # col 3: decomposition at Q800 + burst contrast + risk set
    show = [a for a in ("SHAM", "SINK_ONLY_Q800", "SOURCE_ONLY_Q800", "DIRECT_Q800_UNIFORM",
                        "DIRECT_Q400_UNIFORM", "DIRECT_Q400_BURST") if a in S]
    xr = range(len(show))
    alive = [S[a]["I_over_T"]["median"] is not None for a in show]
    ii = [(S[a]["I_over_T"]["median"] if ok else 0.0) for a, ok in zip(show, alive)]
    ff = [(S[a]["F_over_T"]["median"] if ok else 0.0) for a, ok in zip(show, alive)]
    aa = [(max(0.0, 1 - x - y) if ok else 0.0) for x, y, ok in zip(ii, ff, alive)]
    a2.bar(xr, ii, 0.6, color=C["I"], zorder=3, label="I/T incumbent" if i == 0 else None)
    a2.bar(xr, aa, 0.6, bottom=ii, color=C["A"], zorder=3, label="A/T ambiant" if i == 0 else None)
    a2.bar(xr, ff, 0.6, bottom=[x + y for x, y in zip(ii, aa)], color=C["F"], zorder=3,
           label="F/T source" if i == 0 else None)
    for x, (a, ok) in enumerate(zip(show, alive)):
        a2.text(x, 1.05, f"{S[a]['lineage_ok']}/{S[a]['n']}", ha="center", color=INK,
                fontsize=8, fontweight="bold")
        tm = S[a]["T_over_M256"]["median"]
        a2.text(x, -0.09, ("T/M₂₅₆\n" if x == 0 else "") + (f"{tm:.2f}" if tm is not None else "—"),
                ha="center", color=INK2, fontsize=7.6)
        if not ok:
            a2.bar([x], [1.0], 0.6, color="none", edgecolor=C["R"], hatch="///", lw=1.4, zorder=4)
            a2.text(x, 0.5, "piste\nperdue\n0/9", ha="center", va="center", color=C["R"],
                    fontsize=8.4, fontweight="bold", zorder=5)
    a2.axhline(0.20, color=C["R"], lw=1.4, ls="--", zorder=4)
    a2.axhline(0.80, color=C["R"], lw=1.4, zorder=4)
    a2.set_ylim(-0.16, 1.18)
    a2.set_xticks(list(xr))
    a2.set_xticklabels([s.replace("DIRECT_", "").replace("_UNIFORM", "").replace("_ONLY", "-only")
                        .replace("_Q800", "\nQ800") for s in show], fontsize=7.4)
    a2.set_ylabel("composition à l'horizon", color=INK2, fontsize=10)

axes[0][0].set_title("Composition de la piste selon la dose", color=INK, fontsize=11.5,
                     fontweight="bold", pad=8)
axes[0][1].set_title("Cohorte initiale, masse et remplacement apparié", color=INK, fontsize=11.5,
                     fontweight="bold", pad=8)
axes[0][2].set_title("Découplage et effet de cadence", color=INK, fontsize=11.5,
                     fontweight="bold", pad=8)
axes[1][1].set_xlabel("dose (nombre d'événements ; quantum gelé)", color=INK2, fontsize=10)
fig.suptitle("Frontière de remplacement par interface directe — 18 blocs appariés, "
             "quantum gelé, dose = nombre d'événements",
             color=INK, fontsize=14.5, fontweight="bold", y=0.985)
fig.text(0.5, 0.945, f"protocole des DEUX stages scellé avant la première préphase · "
         f"DECISION = {summary['DECISION']} · traits rouges = portes gelées 0,20 et 0,80 · "
         "chiffres au-dessus des barres = lignée intacte / 9 · n = 9 blocs indépendants par taille",
         ha="center", color=INK2, fontsize=9)
fig.tight_layout(rect=[0, 0.075, 1, 0.925])
for j, (ax, xa) in enumerate(zip((axes[0][0], axes[0][1], axes[0][2]), (0.035, 0.365, 0.715))):
    h, l = ax.get_legend_handles_labels()
    fig.legend(h, l, frameon=False, fontsize=7.8, labelcolor=INK2, ncol=2,
               loc="lower left", bbox_to_anchor=(xa, 0.002))
fig.savefig("direct_replacement_frontier.png", dpi=170, facecolor=SURF)
print("figure -> direct_replacement_frontier.png")
