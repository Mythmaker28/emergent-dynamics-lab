"""ROUTE_E_DIRECT_INTERFACE_REPLACEMENT_FRONTIER_DEV_05 -- staged prospective run.

Refuses every engine call unless direct_replacement_protocol.json matches its sealed SHA-256
and the sealed code hashes still match. Production engine untouched.

  python3 dr_harness.py A     -> 18 prephases + SHAM + DIRECT_Q100_ANCHOR
  python3 dr_harness.py B     -> the six pre-sealed Stage B arms (refuses if the Stage A gate failed)
"""
from __future__ import annotations
import csv, hashlib, json, math, sys, time
from pathlib import Path
import numpy as np

from od_core import (LatticeBondEngine, LatticeBondState, comps, largest_bounded, cells_of,
                     fhash, THRESH)
from dr_core import (Prov, Lineage, direct_event, build_masks_05, snapshot, depth_partition,
                     COHORTS, INCUMBENT, TOL)
from bridge00_harness import law_arms
from morph02_ic import ic_single_disc

# ----------------------------------------------------------------- constants
P = 0.35
SIZES = (24, 32)
SEEDS_PER = 9
SEED_BASE = 990000                      # DEV_DIRECT_REPLACEMENT_05, never reused
T_B = 256
CAD = 16                                # lineage / tracker cadence
METRIC_EVERY = 128                      # scaffold + full metric cadence
COAST = 2048
AXORD = ("+x", "-x", "+y", "-y")
N_EVENTS_Q100 = 80
SPACING = 16                            # uniform inter-event spacing, identical in every arm
BURST_N = 8
BURST_SPACING = 4


def uniform_sched(n_events):
    return [272 + SPACING * (e - 1) for e in range(1, n_events + 1)]


def burst_sched(n_events, first, last):
    """Same dose, same quantum, same first and last force time as the uniform arm of the same
    dose; only the intermediate distribution differs."""
    per = n_events // BURST_N
    span = (per - 1) * BURST_SPACING
    last_start = last - span
    out = []
    for b in range(BURST_N):
        start = first + round(b * (last_start - first) / (BURST_N - 1))
        out += [start + k * BURST_SPACING for k in range(per)]
    return sorted(set(out))


SCHED = {}
SCHED["DIRECT_Q100_ANCHOR"] = uniform_sched(80)
SCHED["DIRECT_Q200_UNIFORM"] = uniform_sched(160)
SCHED["DIRECT_Q400_UNIFORM"] = uniform_sched(320)
SCHED["DIRECT_Q800_UNIFORM"] = uniform_sched(640)
SCHED["SINK_ONLY_Q800"] = uniform_sched(640)
SCHED["SOURCE_ONLY_Q800"] = uniform_sched(640)
SCHED["DIRECT_Q400_BURST"] = burst_sched(320, 272, uniform_sched(320)[-1])
SCHED["SHAM"] = []

MODE = {"SHAM": "SHAM", "DIRECT_Q100_ANCHOR": "DIRECT", "DIRECT_Q200_UNIFORM": "DIRECT",
        "DIRECT_Q400_UNIFORM": "DIRECT", "DIRECT_Q800_UNIFORM": "DIRECT",
        "DIRECT_Q400_BURST": "DIRECT", "SINK_ONLY_Q800": "SINK_ONLY",
        "SOURCE_ONLY_Q800": "SOURCE_ONLY"}
STAGE_A = ["SHAM", "DIRECT_Q100_ANCHOR"]
STAGE_B = ["DIRECT_Q200_UNIFORM", "DIRECT_Q400_UNIFORM", "DIRECT_Q800_UNIFORM",
           "DIRECT_Q400_BURST", "SINK_ONLY_Q800", "SOURCE_ONLY_Q800"]
ALL_ARMS = STAGE_A + STAGE_B

TERM = {a: (SCHED[a][-1] + COAST if SCHED[a] else 0) for a in ALL_ARMS}
LONGEST = max(TERM.values())
TERM["SHAM"] = LONGEST
REQUIRED_TIMES = sorted({T_B} | {t for a in ALL_ARMS if SCHED[a]
                                 for t in (SCHED[a][-1], SCHED[a][-1] + 16,
                                           SCHED[a][-1] + 128, SCHED[a][-1] + COAST)})

PROTOCOL = "direct_replacement_protocol.json"
SEAL = "direct_replacement_protocol.sha256"
GATE_FILE = "stage_a_gate.json"


def preseal_guard():
    p, s = Path(PROTOCOL), Path(SEAL)
    if not p.exists() or not s.exists():
        sys.exit("PRESEAL_GUARD: protocol or seal missing -- no engine call permitted.")
    got = hashlib.sha256(p.read_bytes()).hexdigest()
    want = s.read_text().split()[0].strip()
    if got != want:
        sys.exit(f"PRESEAL_GUARD: protocol hash mismatch\n sealed={want}\n actual={got}")
    rec = json.loads(p.read_text())["code_sha256"]
    for f, h in rec.items():
        cur = hashlib.sha256(Path(f).read_bytes()).hexdigest()
        if cur != h:
            sys.exit(f"PRESEAL_GUARD: {f} changed after seal\n sealed={h}\n actual={cur}")
    return got


def prephase(law, m, L):
    eng = LatticeBondEngine(law)
    st = LatticeBondState(m.copy(), np.full((L, L), 0.8), np.zeros((2, L, L)), 0)
    while int(st.step) < T_B:
        st = eng.step(st).state
    return st


def branch(law, st0, masks, arm, L, cells256, blk, ev_rows, lin_rows):
    mode = MODE[arm]
    sched = set(SCHED[arm])
    horizon = TERM[arm]
    eng = LatticeBondEngine(law)
    st = st0.copy()
    prov = Prov(st, cells256, L)
    M256 = prov.M256
    I0 = prov.incumbent_in(cells256)
    qe = M256 / N_EVENTS_Q100            # FROZEN quantum, identical in every dosed arm
    lin = Lineage()
    total0 = float(st.m.sum())
    tf = SCHED[arm][-1] if SCHED[arm] else 0
    need = {T_B, tf, tf + 16, tf + 128, tf + COAST} | set(REQUIRED_TIMES)
    snaps = {}
    realized_source = realized_sink = planned_total = 0.0
    removed_tot = {c: 0.0 for c in COHORTS}
    n_events = n_rejected = 0
    max_ident = max_bal = 0.0
    min_delta = float("inf")
    first_cross_turnover = None
    first_cross_source = None
    ev_id = 0

    cur = lin.update(st, T_B)
    s0 = snapshot(st, prov, L, M256, I0)
    snaps[T_B] = s0

    t = int(st.step)
    while t < horizon:
        if t in sched:
            c = largest_bounded(st)
            track = cells_of(c) if c is not None else set()
            tb_id = id(c) if c is not None else None
            if track:
                r = direct_event(st, prov, masks, track, L, qe, mode)
                planned_total += qe
                realized_sink += r["realized_sink"]
                realized_source += r["realized_source"]
                for k in COHORTS:
                    removed_tot[k] += r["removed_by_cohort"][k]
                if r["rejected"]:
                    n_rejected += 1
                else:
                    n_events += 1
                    min_delta = min(min_delta, r["physical_state_delta"])
                ident = prov.identity_residual(st)
                bal = prov.global_balance_residual(st, total0)
                max_ident = max(max_ident, ident)
                max_bal = max(max_bal, bal)
                ev_id += 1
                if ev_id % 8 == 1 or r["rejected"]:      # sub-sampled ledger, every 8th event
                    ev_rows.append({
                        "block": blk, "size": L, "arm": arm, "time": t, "event_id": ev_id,
                        "n_sink_sites": r["n_sink_sites"], "n_source_sites": r["n_source_sites"],
                        "planned": qe, "q_event": r["q_event"],
                        "realized_sink": r["realized_sink"], "realized_source": r["realized_source"],
                        "incumbent_removed": sum(r["removed_by_cohort"][k] for k in INCUMBENT),
                        "ambient_removed": r["removed_by_cohort"]["amb"],
                        "fresh_removed": r["removed_by_cohort"]["fre"],
                        "core_removed": r["removed_by_cohort"]["core"],
                        "inter_removed": r["removed_by_cohort"]["inter"],
                        "bnd_removed": r["removed_by_cohort"]["bnd"],
                        "physical_state_delta": r["physical_state_delta"],
                        "atomic": r["atomic"], "rejected": r["rejected"],
                        "identity_residual": ident, "global_balance_residual": bal})
        pre = st
        o = eng.step(pre)
        prov.advance(pre.m, o.ledger, o.state.m, law.dt)
        st = o.state
        t = int(st.step)
        if t % CAD == 0:
            cur = lin.update(st, t)
            full = (t % METRIC_EVERY == 0) or (t in need)
            if cur is not None:
                cells = cells_of(cur)
                fm = st.m.reshape(-1)
                T = float(sum(fm[i] for i in cells))
                I = prov.incumbent_in(cells)
                F = prov.mass_in(cells, "fre")
                A = prov.mass_in(cells, "amb")
                if first_cross_turnover is None and I0 > 0 and (I / I0) <= 0.20:
                    first_cross_turnover = t
                    need.add(t)
                if first_cross_source is None and T > 0 and (F / T) >= 0.80:
                    first_cross_source = t
                    need.add(t)
                if full:
                    snaps[t] = snapshot(st, prov, L, M256, I0)
                if t % METRIC_EVERY == 0:
                    lin_rows.append({"block": blk, "size": L, "arm": arm, "time": t,
                                     "same_track": lin.continuous, "merger": lin.merger,
                                     "split": lin.split, "loss": lin.lost,
                                     "reacquisition": lin.reacq,
                                     "T": T, "I": I, "F": F, "A": A,
                                     "I_over_I0": I / I0 if I0 > 0 else float("nan"),
                                     "F_over_T": F / T if T > 0 else float("nan"),
                                     "T_over_M256": T / M256})
            else:
                if t % METRIC_EVERY == 0:
                    lin_rows.append({"block": blk, "size": L, "arm": arm, "time": t,
                                     "same_track": False, "merger": lin.merger,
                                     "split": lin.split, "loss": lin.lost,
                                     "reacquisition": lin.reacq,
                                     "T": None, "I": None, "F": None, "A": None,
                                     "I_over_I0": None, "F_over_T": None, "T_over_M256": None})
            max_ident = max(max_ident, prov.identity_residual(st))

    end = snaps.get(horizon) or snapshot(st, prov, L, M256, I0)
    snaps[horizon] = end
    force_end = snaps.get(tf) if tf else None
    row = {"arm": arm, "size": L, "block": blk, "mode": mode, "M256": M256, "I0": I0,
           "quantum": qe, "n_scheduled": len(SCHED[arm]), "n_events": n_events,
           "n_rejected": n_rejected, "terminal_time": horizon, "force_end_time": tf,
           "planned_source": planned_total if mode != "SINK_ONLY" else 0.0,
           "planned_sink": planned_total if mode != "SOURCE_ONLY" else 0.0,
           "realized_source": realized_source, "realized_sink": realized_sink,
           "incumbent_removed_total": sum(removed_tot[k] for k in INCUMBENT),
           "ambient_removed_total": removed_tot["amb"], "fresh_removed_total": removed_tot["fre"],
           "min_physical_state_delta": (None if min_delta == float("inf") else min_delta),
           "same_track_continuous": lin.continuous, "merger": lin.merger, "split": lin.split,
           "loss": lin.lost, "reacquisition": lin.reacq,
           "first_failure_time": lin.first_failure_time,
           "first_failure_type": lin.first_failure_type,
           "first_cross_turnover": first_cross_turnover,
           "first_cross_source": first_cross_source,
           "max_identity_residual": max_ident, "max_global_balance_residual": max_bal,
           "HALO_CONTACT": "NOT_APPLICABLE", "HALO_CAPTURE": "NOT_APPLICABLE",
           "DIRECT_DYNAMIC_CAPTURE": 0.0}
    for tag, s in (("force_end", force_end), ("terminal", end)):
        if s is None or not s.get("track"):
            for k in ("T", "I", "F", "A", "I_over_I0", "I_over_T", "F_over_M256", "F_over_T",
                      "A_over_M256", "A_over_T", "T_over_M256", "scaffold_cells",
                      "scaffold_mass", "scaffold_mass_over_I0",
                      "core_in_track", "inter_in_track", "bnd_in_track"):
                row[f"{tag}_{k}"] = None
        else:
            for k in ("T", "I", "F", "A", "I_over_I0", "I_over_T", "F_over_M256", "F_over_T",
                      "A_over_M256", "A_over_T", "T_over_M256", "scaffold_cells",
                      "scaffold_mass", "scaffold_mass_over_I0",
                      "core_in_track", "inter_in_track", "bnd_in_track"):
                row[f"{tag}_{k}"] = s.get(k)
    row["snapshots"] = json.dumps({str(k): {kk: vv for kk, vv in v.items() if kk != "cells"}
                                   for k, v in sorted(snaps.items())})
    return row


def run(stage):
    seal = preseal_guard()
    print(f"PRESEAL_GUARD OK  protocol sha256 = {seal}")
    arms = STAGE_A if stage == "A" else STAGE_B
    if stage == "B":
        g = json.loads(Path(GATE_FILE).read_text())
        if g["STAGE_A_GATE"] != "PASS":
            sys.exit(f"STAGE_A_GATE = {g['STAGE_A_GATE']} -> Stage B is not authorised.")
        print("STAGE_A_GATE = PASS -> Stage B authorised")
    law = law_arms()["LAW_16"]
    rows, ev, lin_rows, manifest = [], [], [], []
    calls = 0
    t0 = time.time()
    for li, L in enumerate(SIZES):
        for k in range(SEEDS_PER):
            seed = SEED_BASE + li * 100 + k
            blk = f"L{L}_S{seed}"
            m = np.ascontiguousarray(ic_single_disc(np.random.default_rng(seed), L, P),
                                     dtype=np.float64)
            h0 = fhash(m, np.full((L, L), 0.8), np.zeros((2, L, L)))
            if stage == "A":
                st = prephase(law, m, L)
                calls += 1
                np.save(f"_t256_{blk}.npy", np.stack([st.m, st.n]))
                np.save(f"_t256b_{blk}.npy", st.b)
            else:
                a = np.load(f"_t256_{blk}.npy"); b = np.load(f"_t256b_{blk}.npy")
                st = LatticeBondState(np.ascontiguousarray(a[0]), np.ascontiguousarray(a[1]),
                                      np.ascontiguousarray(b), T_B)
            c = largest_bounded(st)
            ncomp = len(comps(st))
            status = ("T256_VALID_TRACK" if (c is not None and not (c.wraps_x or c.wraps_y))
                      else "T256_DISSOLVED" if ncomp == 0
                      else "T256_WRAPPING" if c is not None else "T256_TRACK_LOST")
            if status != "T256_VALID_TRACK":
                manifest.append({"block": blk, "size": L, "seed": seed, "t256_status": status})
                continue
            cells = cells_of(c)
            hb = fhash(st.m, st.n, st.b)
            axis = AXORD[k % 4]
            masks = build_masks_05(cells, L, c.centroid_y, c.centroid_x, axis)
            core, inter, bnd = depth_partition(cells, L)
            probe = Prov(st, cells, L)
            init_ok = (abs(probe.incumbent_in(cells) - probe.M256) <= 1e-12
                       and probe.mass_in(cells, "amb") == 0.0
                       and probe.mass_in(cells, "fre") == 0.0)
            if stage == "A":
                manifest.append({"block": blk, "size": L, "seed": seed, "axis": axis,
                                 "t256_status": status, "t0_sha256": h0,
                                 "t256_sha256": hb, "M256": probe.M256,
                                 "area256": c.area, "n_components_t256": ncomp,
                                 "n_core": len(core), "n_inter": len(inter), "n_bnd": len(bnd),
                                 "mask_sink": len(masks["sink"]), "mask_source": len(masks["source"]),
                                 "t256_initialisation_exact": init_ok})
            copies = {a: st.copy() for a in arms}
            ref = copies[arms[0]]
            for a in arms:
                assert np.array_equal(ref.m, copies[a].m) and np.array_equal(ref.n, copies[a].n) \
                       and np.array_equal(ref.b, copies[a].b)
                assert fhash(copies[a].m, copies[a].n, copies[a].b) == hb
            for a in arms:
                r = branch(law, copies[a], masks, a, L, cells, blk, ev, lin_rows)
                calls += 1
                r.update(seed=seed, axis=axis, t0_sha256=h0, t256_sha256=hb,
                         t256_status=status, t256_initialisation_exact=init_ok,
                         n_core=len(core), n_inter=len(inter), n_bnd=len(bnd))
                rows.append(r)
                print(f"  [{stage}] {blk} {a:<22} ({len(rows)}/{len(arms)*18}, "
                      f"{time.time()-t0:.0f}s)", flush=True)

    suff = stage.lower()
    if stage == "A":
        Path("t256_checkpoint_manifest.json").write_text(json.dumps(
            {"mission": "ROUTE_E_DIRECT_INTERFACE_REPLACEMENT_FRONTIER_DEV_05",
             "protocol_sha256": seal, "blocks": manifest,
             "prephase_invocations": 18}, indent=1))
    for name, data in ((f"direct_replacement_rows_{suff}.csv", rows),
                       (f"direct_replacement_event_ledger_{suff}.csv", ev),
                       (f"direct_replacement_lineage_ledger_{suff}.csv", lin_rows)):
        if not data:
            continue
        f = sorted({k for d in data for k in d})
        with Path(name).open("w", newline="") as h:
            w = csv.DictWriter(h, fieldnames=f); w.writeheader(); w.writerows(data)
    Path(f"_calls_{suff}.json").write_text(json.dumps({"engine_invocations": calls}))
    print(f"\nstage {stage}: {len(rows)} trajectoires, {calls} appels moteur "
          f"({time.time()-t0:.0f}s)")


if __name__ == "__main__":
    run(sys.argv[1] if len(sys.argv) > 1 else "A")
