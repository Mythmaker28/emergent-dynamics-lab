"""ROUTE_E_REDESIGN_SOURCE_CAPTURE_DEV_02 — lever la limitation de capture.
Leviers designes par les donnees de DECOMPOSE_01: distance de source et regime d impulsions.
Moteur de production inchange. Lecture PER_TRACK. Protocole scelle AVANT tout appel moteur."""
from __future__ import annotations
import csv, json, math, time
from pathlib import Path
import numpy as np
from od_core import *
from od_ops import do_event
from bridge00_harness import law_arms
from morph02_ic import ic_single_disc

CAD=16; T_B=256; T_F=1536; T_E=2048; P=0.35; SIZES=(24,32); SEEDS_PER=9
ARMS=["SHAM",
      "COUPLED_D2_SMOOTH_LOW",      # reference reprise de DECOMPOSE_01
      "COUPLED_D1_SMOOTH_LOW",      # levier distance
      "COUPLED_D1_PULSE_LOW",       # levier distance + impulsions
      "COUPLED_D1_BURST_LOW",       # peu d evenements, gros quotas
      "COUPLED_D1_PULSE_MID",       # + dose
      "COUPLED_D1_SMOOTH_MID",
      "COUPLED_D1_PULSE_HIGH"]
AXORD=("+x","-x","+y","-y")
SMOOTH=[272+16*(e-1) for e in range(1,81)]
PULSE=[272+math.floor((e-1)*1264/19) for e in range(1,21)]
BURST=[272+math.floor((e-1)*1264/4) for e in range(1,6)]
def sched(a): return BURST if "BURST" in a else (PULSE if "PULSE" in a else SMOOTH)
def dose(a,M): return (0.15 if "HIGH" in a else 0.10 if "MID" in a else 0.05)*M
def srckey(a): return "source_d1" if "_D1_" in a else "source_near"

def build_masks2(cells,L,cy,cx,axis):
    mk=build_masks(cells,L,cy,cx,axis)
    dy,dx=AXES[axis]; yy,xx=np.mgrid[0:L,0:L]
    proj=((yy-cy)*dy+(xx-cx)*dx).reshape(-1); gd=graph_distance(cells,L)
    mk["source_d1"]=sorted([i for i in range(L*L) if gd[i]==1 and proj[i]<0.0],key=lambda i:(proj[i],i))
    return mk

def prephase(law,m,L):
    eng=LatticeBondEngine(law); st=LatticeBondState(m.copy(),np.full((L,L),0.8),np.zeros((2,L,L)),0)
    while int(st.step)<T_B: st=eng.step(st).state
    return st

def branch(law,st0,masks,arm,L,M256,cs256):
    eng=LatticeBondEngine(law); st=st0.copy()
    init=np.zeros_like(st.m); fi=init.reshape(-1); fm=st.m.reshape(-1)
    for i in cs256: fi[i]=fm[i]
    fresh=np.zeros_like(st.m)
    S=set(sched(arm)); Q=dose(arm,M256); qe=Q/len(sched(arm))
    res={"sink":0.0,"source":0.0}; tot0=float(st.m.sum())
    egress=0.0; transit=0.0; defi=0.0; latt=0.0; maxfresh=0.0; rem=0.0; inj=0.0
    first=None; ftype="NONE"; prev=None; snap={}; fresh_next=None
    t=int(st.step)
    # remappe la cle de source pour do_event (qui lit source_near / source_far)
    mk=dict(masks); mk["source_near"]=masks[srckey(arm)]
    while t<T_E:
        if t in S:
            pt=per_track(st,init,fresh,M256)
            if arm=="SHAM":
                _=pick_distributed(mk["sink_distributed"],st.m.reshape(-1),pt["cells"],L,qe); defi+=qe
            else:
                r=do_event(st,init,fresh,pt["cells"],mk,arm.replace("_D1_","_NEAR_").replace("_D2_","_NEAR_"),qe,L,res)
                rem+=r["removed"]; inj+=r["injected"]; egress+=r["init_egress"]; transit+=r["transit"]
                defi+=r["deficit"]; latt=max(latt,r["lattice_balance_error"])
        pre=st; out=eng.step(pre)
        init=advect(init,pre.m,out.ledger,out.state.m,law.dt)
        fresh=advect(fresh,pre.m,out.ledger,out.state.m,law.dt)
        st=out.state; t=int(st.step)
        if t%CAD==0:
            pt=per_track(st,init,fresh,M256)
            if pt["track"]: maxfresh=max(maxfresh,pt["fresh_in_track"])
            bad=None
            if not pt["track"]: bad="TRACK_LOST_OR_DISSOLVED"
            elif pt["wrap"]: bad="WRAPPING"
            elif prev is not None:
                d=math.hypot(pt["cy"]-prev["cy"],pt["cx"]-prev["cx"]); ar=pt["area"]/max(1,prev["area"])
                if d>3.0 or not (1/3.0<=ar<=3.0): bad="TRACK_LOSS"
            if bad and first is None: first=t; ftype=bad
            if pt["track"]: prev=pt
            if t in (288,1536,2048): snap[t]=pt
    sys_err=abs(float(st.m.sum())+res["sink"]+res["source"]-tot0)
    def alive(H): return first is None or first>H
    gate=0.80*Q
    def okH(H):
        s=snap.get(H)
        return bool(s and s["track"] and not s["wrap"] and alive(H) and 0.75*M256<=s["mass"]<=1.25*M256)
    ing_ok=maxfresh>=gate; eg_ok=egress>=gate
    joint=bool(okH(1536) and okH(2048) and ing_ok and eg_ok and sys_err<=1e-9 and alive(2048))
    def v(H,k):
        s=snap.get(H); return s[k] if (s and s["endpoint_defined"] and alive(H)) else None
    return {"arm":arm,"M256":M256,"Q":Q,"n_events":len(sched(arm)),"q_per_event":qe,
            "realized_sink_removal":rem,"realized_source_injection":inj,
            "unique_initial_egress":egress,"unique_fresh_ingress":maxfresh,"gate":gate,
            "egress_gate_met":eg_ok,"ingress_gate_met":ing_ok,
            "directional_transit_mass":transit,"flux_deficit":defi,
            "lattice_balance_error":latt,"total_system_balance_error":sys_err,
            "fresh_at_first_checkpoint":(snap.get(288) or {}).get("fresh_in_track"),
            "survival_1536":alive(1536),"survival_2048":alive(2048),"coast_survival":alive(2048),
            "first_failure_time":first,"first_failure_type":ftype,
            "initial_residual_2048":v(2048,"initial_residual"),"fresh_fraction_2048":v(2048,"fresh_fraction"),
            "initial_residual_1536":v(1536,"initial_residual"),"fresh_fraction_1536":v(1536,"fresh_fraction"),
            "joint_capture_success":joint}

def main():
    law=law_arms()["LAW_16"]; rows=[]; man=[]; t0=time.time()
    for li,L in enumerate(SIZES):
        for k in range(SEEDS_PER):
            seed=960000+li*100+k
            m=np.ascontiguousarray(ic_single_disc(np.random.default_rng(seed),L,P),dtype=np.float64)
            h0=fhash(m,np.full((L,L),0.8),np.zeros((2,L,L)))
            st=prephase(law,m,L); c=largest_bounded(st)
            status="T256_VALID_TRACK" if c is not None and not (c.wraps_x or c.wraps_y) else "T256_INVALID"
            if status!="T256_VALID_TRACK":
                for a in ARMS: rows.append({"L":L,"seed":seed,"arm":a,"t256_status":status,"t0_sha256":h0})
                continue
            cs=cells_of(c); M=float(sum(st.m.reshape(-1)[i] for i in cs))
            axis=AXORD[k%4]; masks=build_masks2(cs,L,c.centroid_y,c.centroid_x,axis)
            hb=fhash(st.m,st.n,st.b)
            man.append({"L":L,"seed":seed,"axis":axis,"t256_checkpoint_sha256":hb,"M256":M,
                        "masks":{kk:len(vv) for kk,vv in masks.items()}})
            cps={a:st.copy() for a in ARMS}
            assert all(np.array_equal(cps[ARMS[0]].m,cps[a].m) for a in ARMS)
            assert all(fhash(cps[a].m,cps[a].n,cps[a].b)==hb for a in ARMS)
            for a in ARMS:
                r=branch(law,cps[a],masks,a,L,M,cs)
                r.update(L=L,seed=seed,axis=axis,t0_sha256=h0,t256_checkpoint_sha256=hb,t256_status=status)
                rows.append(r)
            print(f"  L={L} seed={seed} ({len(rows)}/144, {time.time()-t0:.0f}s)",flush=True)
    Path("rc_branch_manifest.json").write_text(json.dumps(man,indent=1))
    f=sorted({kk for r in rows for kk in r})
    with Path("redesign_capture_rows.csv").open("w",newline="") as h:
        w=csv.DictWriter(h,fieldnames=f); w.writeheader(); w.writerows(rows)
    print(f"\n{len(rows)} trajectoires ({time.time()-t0:.0f}s)")
if __name__=="__main__": main()
